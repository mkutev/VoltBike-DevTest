Use this code to display featured product slider in homepage.

{{block class="Smartwave\Filterproducts\Block\Home\FeaturedList" name="featured_product" template="grid.phtml"}}