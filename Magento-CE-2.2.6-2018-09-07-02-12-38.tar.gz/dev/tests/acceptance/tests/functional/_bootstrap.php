<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

// Here you can initialize variables that will be available to your tests
require_once dirname(__DIR__) . '/_bootstrap.php';
