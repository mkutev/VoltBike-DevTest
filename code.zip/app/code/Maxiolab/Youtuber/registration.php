<?php

 \Magento\Framework\Component\ComponentRegistrar::register(
     \Magento\Framework\Component\ComponentRegistrar::MODULE,
     'Maxiolab_Youtuber',
     __DIR__
 );