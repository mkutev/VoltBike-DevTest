
var config = {
    "paths": {
        "jquery/fancybox": "Maxiolab_Youtuber/fancybox/jquery.fancybox.min",
        "youtuber": "Maxiolab_Youtuber/js/frontend",
    }
};

require([
    'jquery',
    'jquery/fancybox',
    'youtuber',
]);