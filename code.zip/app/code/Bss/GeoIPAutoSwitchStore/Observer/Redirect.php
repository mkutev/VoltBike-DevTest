<?php
/**
 * BSS Commerce Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://bsscommerce.com/Bss-Commerce-License.txt
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This package designed for Magento COMMUNITY edition
 * BSS Commerce does not guarantee correct work of this extension
 * on any other Magento edition except Magento COMMUNITY edition.
 * BSS Commerce does not provide extension support in case of
 * incorrect edition usage.
 * =================================================================
 *
 * @category   BSS
 * @package    Bss_SeoSuite
 * @author     Extension Team
 * @copyright  Copyright (c) 2015-2016 BSS Commerce Co. ( http://bsscommerce.com )
 * @license    http://bsscommerce.com/Bss-Commerce-License.txt
 */
namespace Bss\GeoIPAutoSwitchStore\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\Action\Context;
use Magento\Store\Api\StoreCookieManagerInterface;
use Magento\Store\Model\StoreResolver;

class Redirect implements ObserverInterface
{
    /**
     * @var \Magento\Framework\App\Response\RedirectInterface
     */
    private $redirect;

    /**
     * @var \Magento\Store\Model\GroupFactory
     */
    private $groupFactory;

    /**
     * @var \Magento\Framework\App\Request\Http
     */
    private $request;

    /**
     * @var StoreCookieManagerInterface
     */
    private $storeCookieManager;

    /**
     * @var \Magento\Catalog\Model\Session
     */
    private $customerSession;

    /**
     * @var \Bss\GeoIPAutoSwitchStore\Cookie\GeoIp
     */
    private $cookieGeoIp;

    /**
     * @var \Bss\GeoIPAutoSwitchStore\Helper\Data
     */
    private $dataHelper;

    /**
     * @var \Bss\GeoIPAutoSwitchStore\Model\GeoIpMaxMindFactory
     */
    private $geoIpMaxMind;

    /**
     * @var \Bss\GeoIPAutoSwitchStore\Model\GeoIpMaxMindIPv6Factory
     */
    private $geoIpMaxMindIPv6;

    /**
     * @var \Magento\Framework\HTTP\PhpEnvironment\RemoteAddress
     */
    private $remoteAddress;

    /**
     * @var \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory
     */
    private $categoryCollectionFactory;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    private $date;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var \Magento\Framework\UrlInterface
     */
    private $url;

    /**
     * @var ActionFlag
     */
    private $actionFlag;

    /**
     * @var \Magento\Framework\App\Response\Http
     */
    private $response;

    /**
     * @var \Magento\Framework\Module\Manager
     */
    private $moduleManager;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    private $productMetadata;

    /**
     * Redirect constructor.
     * @param \Magento\Framework\HTTP\PhpEnvironment\RemoteAddress $remoteAddress
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $date
     * @param \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollectionFactory
     * @param \Bss\GeoIPAutoSwitchStore\Model\GeoIpMaxMindFactory $geoIpMaxMind
     * @param \Bss\GeoIPAutoSwitchStore\Model\GeoIpMaxMindIPv6Factory $geoIpMaxMindIPv6
     * @param \Bss\GeoIPAutoSwitchStore\Helper\Data $dataHelper
     * @param StoreCookieManagerInterface $storeCookieManager
     * @param \Magento\Framework\App\Request\Http $request
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Store\Model\GroupFactory $groupFactory
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Bss\GeoIPAutoSwitchStore\Cookie\GeoIp $cookieGeoIp
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Module\Manager $moduleManager
     * @param Context $context
     */
    public function __construct(
        \Magento\Framework\HTTP\PhpEnvironment\RemoteAddress $remoteAddress,
        \Magento\Framework\Stdlib\DateTime\DateTime $date,
        \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollectionFactory,
        \Bss\GeoIPAutoSwitchStore\Model\GeoIpMaxMindFactory $geoIpMaxMind,
        \Bss\GeoIPAutoSwitchStore\Model\GeoIpMaxMindIPv6Factory $geoIpMaxMindIPv6,
        \Bss\GeoIPAutoSwitchStore\Model\LocationsMaxMindFactory $locationsMaxMind,
        \Bss\GeoIPAutoSwitchStore\Helper\Data $dataHelper,
        StoreCookieManagerInterface $storeCookieManager,
        \Magento\Framework\App\Request\Http $request,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Store\Model\GroupFactory $groupFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Bss\GeoIPAutoSwitchStore\Cookie\GeoIp $cookieGeoIp,
        \Magento\Framework\App\ProductMetadataInterface $productMetadata,
        \Magento\Framework\Module\Manager $moduleManager,
        Context $context
    ) {
        $this->redirect = $context->getRedirect();
        $this->productMetadata = $productMetadata;
        $this->groupFactory = $groupFactory;
        $this->request = $request;
        $this->storeCookieManager = $storeCookieManager;
        $this->customerSession = $customerSession;
        $this->cookieGeoIp = $cookieGeoIp;
        $this->dataHelper = $dataHelper;
        $this->locationsMaxMind = $locationsMaxMind;
        $this->geoIpMaxMind = $geoIpMaxMind;
        $this->geoIpMaxMindIPv6 = $geoIpMaxMindIPv6;
        $this->remoteAddress = $remoteAddress;
        $this->categoryCollectionFactory = $categoryCollectionFactory;
        $this->date = $date;
        $this->storeManager = $storeManager;
        $this->url = $context->getUrl();
        $this->moduleManager = $moduleManager;
        $this->actionFlag = $context->getActionFlag();
    }

    /**
     * @return int
     */
    protected function getStoreId()
    {
        return $this->storeManager->getStore()->getId();
    }

    protected function getParamStore()
    {
        $version = $this->productMetadata->getVersion();

        $checkVersion = version_compare($version, '2.2.6', '>=');

        if ($checkVersion) {
            return '___store';
        } else {
            return '__store';
        }
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     * @return $this|void
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Store\Model\StoreIsInactiveException
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $this->actionFlag->set('', \Magento\Framework\App\Action\Action::FLAG_NO_DISPATCH, true);
        $ipForTester = null;
        $ipForTester = $this->request->getParam('ipTester');

        //Get Enable Cookie
        $enableCookie = $this->dataHelper->getEnableCookie($this->getStoreId());

        $enableBlackList = $this->dataHelper->getEnableBlackList($this->getStoreId());

        $ipCustomer = $this->dataHelper->getIpCustomer($ipForTester);

        //Get Ip not Redirects (Array), if this IP is current Customer IP then not Redirects
        
        $countIp = $this->restrictionIp($ipCustomer);
        //Get Country List, if Current Country of Customer on this Country list then Not redirects
        $countIpBlack = $this->getIpBlackList($ipCustomer);

        //Get Bot as Google Bot, Yahoo..., Not redirects it.
        $userBots = $this->dataHelper->restrictionUserAgent($this->getStoreId());

        //Get Advanced Module
        $advEnableModule = $this->moduleManager->isOutputEnabled('Bss_GeoIPAutoSwitchStore');

        //Check Enable Module
        $enableModule = $this->dataHelper->getEnableModule();

        $countUserBot = 0;
        if ($userBots != NULL && $userBots != '') {
            $userBots = explode(',', $userBots);
            foreach ($userBots as $userBot) {
                $userBot = rtrim($userBot, ' ');
                $userBot = ltrim($userBot, ' ');
                if (strstr(strtolower($_SERVER['HTTP_USER_AGENT']), strtolower($userBot))) {
                    $countUserBot = 1;
                }
            }
        }

        $countryCodeSession = $this->customerSession->getCountryCode();

        if ($countryCodeSession !== null && $ipForTester == null) {

            //If Module Enable, Not User Bot, and is'nt IP block then Handle Redirect
            if ($enableModule == '1' && $advEnableModule && $countUserBot != 1 && $countIp != 1) {
                $countryCode = $countryCodeSession;
                $this->redirectIpBlackList($countIpBlack, $enableBlackList, $observer);
                $this->redirectBlackList($countryCode, $enableBlackList, $observer);
                $this->redirectFunction($countryCode, $enableBlackList, $observer, $ipForTester);
            }
        }
        
        //If have Cookie of Country and Has IP Tester Use this Cookie.
        if ($this->cookieGeoIp->get() !== null && $enableCookie == '1' && $ipForTester == null) {

            //If Module Enable, Not User Bot, and is'nt IP block then Handle Redirect
            if ($enableModule == '1' && $advEnableModule && $countUserBot != 1 && $countIp != 1) {
                $countryCode = $this->cookieGeoIp->get();
                $this->redirectIpBlackList($countIpBlack, $enableBlackList, $observer);
                $this->redirectBlackList($countryCode, $enableBlackList, $observer);
                $this->redirectFunction($countryCode, $enableBlackList, $observer, $ipForTester);
            }
        } else {
            
            //If Module Enable, Not User Bot, and is'nt IP block then Handle Redirect
            if ($enableModule == '1' && $advEnableModule && $countUserBot != 1 && $countIp != 1) {
                $countryCode = null;

                $dataCollection = null;

                //Check if IPv4
                if(filter_var($ipCustomer, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                    $ipArray = explode('.', $ipCustomer);
                    $ipCustomerLong = (16777216*$ipArray[0])+(65536*$ipArray[1])+(256*$ipArray[2] )+$ipArray[3];
                    //Ip of Customer convert to Long Ip
                    $collection = $this->geoIpMaxMind->create()
                    ->getCollection()
                    ->addFieldToFilter(
                        'begin_ip',
                        ['lteq' => $ipCustomerLong]
                    )->addFieldToFilter('end_ip', ['gteq' => $ipCustomerLong]);
                    $dataCollection = $collection->getData();
                } elseif(filter_var($ipCustomer, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
                    
                    $ipv6Long = $this->ipv6ToLong($ipCustomer);
                    $collection = $this->geoIpMaxMindIPv6->create()
                    ->getCollection()
                    ->addFieldToFilter(
                        'begin_ip',
                        ['lteq' => $ipv6Long]
                    )->addFieldToFilter('end_ip', ['gteq' => $ipv6Long]);
                    $dataCollection = $collection->getData();
                }
                $countryCode = $this->getCountryByIpInfo($ipCustomer, $dataCollection);

                //If have Country Code Redirect Customer
                if ($countryCode) {
                    $this->saveCountryCookie($countryCode, $enableCookie, $ipForTester);
                    $this->redirectIpBlackList($countIpBlack, $enableBlackList, $observer);
                    $this->redirectBlackList($countryCode, $enableBlackList, $observer);
                    $this->redirectFunction($countryCode, $enableBlackList, $observer, $ipForTester);
                }
            }
        }
        return $this;
    }

    /**
     * @param $ip
     * @return bool|string
     */
    protected function ipv6ToLong($ip) {
        $pton = inet_pton($ip);
        if (!$pton) { return false; }
        $number = '';
        foreach (unpack('C*', $pton) as $byte) {
            $number .= str_pad(decbin($byte), 8, '0', STR_PAD_LEFT);
        }
        return base_convert(ltrim($number, '0'), 2, 10);
    }

    /**
     * @param $ipCustomer
     * @param $dataCollection
     * @return mixed|null
     */
    protected function getCountryByIpInfo($ipCustomer, $dataCollection)
    {
        $countryCode = null;

        if ($dataCollection) {
            $network = $dataCollection[0]['geoname_id'];
            $collection = $this->locationsMaxMind->create()
                ->getCollection()
                ->addFieldToFilter(
                    'geoname_id',
                    ['eq' => $network]
                )
                ->addFieldToFilter(
                    'locale_code',
                    ['eq' => 'en']
                );
            $locationCollection = $collection->getData();
            $countryCode = $locationCollection[0]['country_iso_code'];

        } else {
            try {
                $url = 'http://ipinfo.io/'.$ipCustomer.'/json';
                $javascript_loop = 0;
                $timeout = 5;
                $url = str_replace( "&amp;", "&", urldecode(trim($url)) );
                $ch = curl_init();
                curl_setopt( $ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; rv:1.7.3) Gecko/20041001 Firefox/0.10.1" );
                curl_setopt( $ch, CURLOPT_URL, $url );
                curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true );
                curl_setopt( $ch, CURLOPT_ENCODING, "" );
                curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
                curl_setopt( $ch, CURLOPT_AUTOREFERER, true );
                curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
                curl_setopt( $ch, CURLOPT_CONNECTTIMEOUT, $timeout );
                curl_setopt( $ch, CURLOPT_TIMEOUT, $timeout );
                curl_setopt( $ch, CURLOPT_MAXREDIRS, 10 );
                $response = curl_exec( $ch );
                curl_close ( $ch );
                $response = json_decode($response, true);

                if(is_array($response) && isset($response['country'])) {
                    $countryCode = $response['country'];
                }
            } catch (\Exception $e) {
            }
            
        }
        return $countryCode;
    }

    /**
     * @param $countryCode
     * @param $enableCookie
     * @param $ipForTester
     * @return $this
     */
    protected function saveCountryCookie($countryCode, $enableCookie, $ipForTester)
    {
        if ($enableCookie == '1' && $ipForTester == null) {
            $timeCookie = (int)$this->dataHelper->getTimeCookie($this->getStoreId());
            $timeCookie = $timeCookie*24*60*60;
            //Set Cookie Country Code to Browser Customer
            $this->cookieGeoIp->set($countryCode, $timeCookie);
            $this->customerSession->setCountryCode($countryCode);
            return $this;
        } else {
            return $this;
        }
        
    }

    /**
     * @param string $ipCustomer
     * @return int
     */
    protected function getIpBlackList($ipCustomer)
    {
        $ipBlackList = $this->dataHelper->getIpBlackList($this->getStoreId());
        $countIpBlack = 0;

        if ($ipBlackList != null && $ipBlackList != '') {
            $ipList = explode("\n", $ipBlackList);

            foreach ($ipList as $ip) {
                $ip = rtrim($ip, "\n");
                $ip = rtrim($ip, "\r");
                $ip = rtrim($ip, " ");
                $ip = ltrim($ip, "\n");
                $ip = ltrim($ip, "\r");
                $ip = ltrim($ip, " ");
                if ($ipCustomer == $ip) {
                    $countIpBlack = 1;
                }
            }
        }
        return $countIpBlack;
    }

    /**
     * @param $ipCustomer
     * @return int
     */
    protected function restrictionIp($ipCustomer)
    {
        $restrictionIps = $this->dataHelper->restrictionIp($this->getStoreId());
        $countIp = 0;

        if ($restrictionIps != null && $restrictionIps != '') {
            $restrictionIps = explode("\n", $restrictionIps);
        
            foreach ($restrictionIps as $restrictionIp) {
                $restrictionIp = rtrim($restrictionIp, "\n");
                $restrictionIp = rtrim($restrictionIp, "\r");
                $restrictionIp = rtrim($restrictionIp, " ");
                $restrictionIp = ltrim($restrictionIp, "\n");
                $restrictionIp = ltrim($restrictionIp, "\r");
                $restrictionIp = ltrim($restrictionIp, ' ');
                if ($ipCustomer == $restrictionIp) {
                    $countIp = 1;
                }
            }
        }
        return $countIp;
    }

    /**
     * @return string
     */
    protected function getStoreIdFromWebsite()
    {

        $websiteId = $this->storeManager->getStore()->getWebsiteId();
        $sotresView = $this->groupFactory->create()->getCollection()->addFieldToFilter('website_id', $websiteId);
        $storeViewId = '';

        foreach ($sotresView as $storeView) {
            foreach ($storeView->getStores() as $myStore) {
                $storeViewId = $storeViewId.$myStore->getId().',';
            }
        }
        return $storeViewId;
    }

    /**
     * @return string
     */
    protected function getStoreIdFromGroup()
    {

        $groupId = $this->storeManager->getStore()->getGroupId();
        $sotresView = $this->groupFactory->create()->getCollection()->addFieldToFilter('group_id', $groupId);
        $storeViewId = '';

        foreach ($sotresView as $storeView) {
            foreach ($storeView->getStores() as $myStore) {
                $storeViewId = $storeViewId.$myStore->getId().',';
            }
        }
        return $storeViewId;
    }

    /**
     * @param $countryCode
     * @return bool
     */
    private function stopRedirect($countryCode)
    {
        $storeCode = $this->request->getParam($this->getParamStore());
        $stores = $this->storeManager->getStores(false);
        foreach ($stores as $store) {
            $countryStore = $this->dataHelper->getCountries($store->getId());
            if (strpos($countryStore, $countryCode) !== false) {
                if ($storeCode && ($store->getCode() == $storeCode)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * @param $alowSwitch
     * @param $cookieStore
     * @return bool
     */
    protected function checkReturn($alowSwitch, $cookieStore, $observer)
    {
        //If Allow Switch Store and is Default Redirects URL.
        //False is Status not Return.
        if ($alowSwitch == '1' && $this->checkDefaultUrl()) {
            return false;
        }

        if ($alowSwitch == '1' && $this->cookieGeoIp->getUrl()) {
            $saveUrl = $this->cookieGeoIp->getUrl();
            $url = $this->url->getCurrentUrl();

            if (strpos($url, $saveUrl) === false) {
                return true;
            }
        }

        //In Magento 2.2.6 Not have Cookie Store for Default Store. So we can detect URL is Switch to Default Store View by check current URL:
        
        if ($this->request->getOriginalPathInfo() == '/stores/store/redirect/' || $this->request->getOriginalPathInfo() == '/stores/store/switch/') {
            $countRedirects = $this->getCountSwitch();
            $countRedirects++;
            $this->customerSession->setCountSwitch($countRedirects);
            return true;
        } else {
            $countRedirects = $this->getCountSwitch();
            $this->customerSession->setCountSwitch($countRedirects);
            if ($countRedirects >= 2) {
                //Set current Store
                $this->storeManager->setCurrentStore($this->storeManager->getStore()->getId());

                $this->storeCookieManager->setStoreCookie($this->storeManager->getStore());
                $this->customerSession->setCountSwitch(0);

                $redirectUrl = $this->url->getCurrentUrl();
                $urlObject = explode('?', $redirectUrl);
                $newUrl = $urlObject[0];
                $this->actionFlag->set('', \Magento\Framework\App\Action\Action::FLAG_NO_DISPATCH, true);
                $response = $observer->getResponse();
                $response->setRedirect($newUrl)->sendResponse();
                return true;
                
            }
        }

        //If Allow Switch and Cookie Store Available
        if ($alowSwitch == '1' && $cookieStore) {
            $this->actionFlag->set('', \Magento\Framework\App\Action\Action::FLAG_NO_DISPATCH, true);
            return true;
        }

        if ($alowSwitch == '0') {
            $countRedirects = $this->getCountRedirects();
            $countRedirects++;

            $this->customerSession->setCountRedirects($countRedirects);
            if ($countRedirects == 3) {
                $this->customerSession->setCountRedirects(0);
                return true;
            }
        }

        return false;
    }

    /**
     * @param $countryCode
     * @param $enableBlackList
     * @param $observer
     * @param $ipForTester
     * @return $this
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Store\Model\StoreIsInactiveException
     */
    protected function redirectFunction($countryCode, $enableBlackList, $observer, $ipForTester)
    {
        $alowSwitch = $this->dataHelper->getAllowSwitch($this->getStoreId());
        //Get Redirects Scope to Redirects
        $redirectScope = $this->dataHelper->getRedirectsScope($this->getStoreId());

        //Get Cookie Store
        $cookieStore = $this->request->getParam(
            StoreResolver::PARAM_NAME,
            $this->storeCookieManager->getStoreCodeFromCookie());

        $stores = $this->storeManager->getStores(false);

        $checkReturn = $this->checkReturn($alowSwitch, $cookieStore, $observer);

        //3 option to NOT Redirect URL:
        //1. Check Return, this function check a URL is Default Redirects URL or check is Switch Store, check is second time redirects...
        //2. Check URL is Redirects URL with: Current Store View == Store with Country in Config.
        //3. Check URL is'nt Restriction URL.
        if ($checkReturn || $this->stopRedirect($countryCode) || !$this->checkIsUrl()) {
            return $this;
        }

        foreach ($stores as $store) {

            $countryStore = $this->dataHelper->getCountries($store->getId());

            if (strpos($countryStore, $countryCode) !== false) {
                $currentStoreView = ','.$store->getId().',';
                if ($redirectScope == 'website') {
                    $storeViewIdScope = ','.$this->getStoreIdFromWebsite();
                    if ( strpos($storeViewIdScope, $currentStoreView) === false ) {
                        continue;
                    }
                }

                if ($redirectScope == 'store') {
                    $storeViewIdScope = ','.$this->getStoreIdFromGroup();
                    if ( strpos($storeViewIdScope, $currentStoreView) === false ) {
                        continue;
                    }
                }

                //Set current Store
                $this->storeManager->setCurrentStore($store->getId());

                //Save Store Cookie
                $this->storeCookieManager->setStoreCookie($store);
                
                $currentPath = $this->getCurrentPath($observer);
                $redirectUrl = $store->getBaseUrl().$currentPath;

                //Redirects To url of Store (Because save Store Cookie but not Redirects)
                $redirectUrl = $this->addStoreVarnishCache($redirectUrl, $store, $alowSwitch);

                $countRedirects = $this->getCountRedirects();
                $countRedirects++;

                $this->customerSession->setCountRedirects($countRedirects);
                $this->cookieGeoIp->setUrl($store->getBaseUrl(), 86400);
                
                $this->actionFlag->set('', \Magento\Framework\App\Action\Action::FLAG_NO_DISPATCH, true);
                $response = $observer->getResponse();
                $response->setRedirect($redirectUrl)->sendResponse();
                return true;
            }
        }

        return $this;
    }


    /**
     * @return string
     */
    protected function getCountRedirects()
    {
        $countRedirects = $this->customerSession->getCountRedirects();
        if ($countRedirects) {
            return $countRedirects;
        } else {
            return 0;
        }
    }

    /**
     * @return string
     */
    protected function getCountSwitch()
    {
        $countRedirects = $this->customerSession->getCountSwitch();
        if ($countRedirects) {
            return $countRedirects;
        } else {
            return 0;
        }
    }

    /**
     * @return string
     */
    protected function addStoreVarnishCache($redirectUrl, $storeRedirects, $alowSwitch)
    {
        $redirectUrlArray = explode('?', $redirectUrl);

        if (isset($redirectUrlArray[1])) {
            $param = $redirectUrlArray[1];
            $listParam = explode('&', $param);
            foreach ($listParam as $key => $value) {
                if (strpos($value, $this->getParamStore()) !== false) {
                    return $redirectUrl;
                }
            }
        }

        //For Varnish Cache
        if (strpos($redirectUrl, '?') !== false) {
            $redirectUrl .= '&'.$this->getParamStore().'=' . $storeRedirects->getCode();
        } else {
            $redirectUrl .= '?'.$this->getParamStore().'=' . $storeRedirects->getCode();
        }
        return $redirectUrl;
    }

    /**
     * @return string
     */
    protected function getCurrentPath($observer)
    {
        $request = $observer->getData('request');
        $currentPath = $request->getOriginalPathInfo();
        $currentPath = ltrim($currentPath, '/');
        
        $url = $this->url->getCurrentUrl();

        if ($currentPath !== null && $currentPath !== '') {
            $currentPath = strstr($url, $currentPath);
        } else {
            $currentPath = strstr($url, '?');
        }
        return $currentPath;
    }

    /**
     * @param string $countryCode
     * @param string $enableBlackList
     * @return $this
     */
    protected function redirectBlackList($countryCode, $enableBlackList, $observer)
    {
        $stores = $this->storeManager->getStores(false);

        foreach ($stores as $store) {
            $countryStore = $this->dataHelper->getCountriesBlackList($store->getId());
            if (strpos($countryStore, $countryCode) !== false) {
                $urlRedirects = $this->dataHelper->getUrlBlackList($this->getStoreId());
                $urlRedirects = ltrim($urlRedirects, ' ');
                $urlRedirect = null;
                if (strpos($urlRedirects, 'http') !== false) {
                    $urlRedirect = $urlRedirects;
                } else {
                    $urlRedirect = $this->url->getUrl($urlRedirects);
                }
                $checkUrl = $this->checkIsUrl();

                if ($this->getStoreId() != $store->getId() && $checkUrl) {
                    $currentUrl = $this->storeManager->getStore()->getCurrentUrl(false);
                    if (strpos($currentUrl, $urlRedirect) === false && $enableBlackList == '1') {
                        $response = $observer->getResponse();
                        $response->setRedirect($urlRedirect)->sendResponse();
                        return $this;
                    }
                }
            }
        }
        return $this;
    }

    /**
     * @param string $ipCount
     * @param string $enableBlackList
     * @return $this
     */
    protected function redirectIpBlackList($ipCount, $enableBlackList, $observer)
    {
        $urlRedirects = $this->dataHelper->getUrlBlackList($this->getStoreId());
        $urlRedirects = ltrim($urlRedirects, ' ');
        $urlRedirect = null;
        if (strpos($urlRedirects, 'http') !== false) {
            $urlRedirect = $urlRedirects;
        } else {
            $urlRedirect = $this->url->getUrl($urlRedirects);
        }
        $currentUrl = $this->storeManager->getStore()->getCurrentUrl(false);
        if (strpos($currentUrl, $urlRedirect) === false && $ipCount != 0 && $enableBlackList == '1') {
            $response = $observer->getResponse();
            $response->setRedirect($urlRedirect)->sendResponse();
            return $this;
        }
        return $this;
    }

    /**
     * @return bool
     */
    protected function checkDefaultUrl()
    {
        //Default Redirect URLs is Url allways redirects.
        $count = 0;
        //Get config Url Redirects Default.
        $defaultUrl = $this->dataHelper->getDefaultRedirect($this->getStoreId());

        if ($defaultUrl != null && $defaultUrl != '') {
            $urlArray = explode("\n", $defaultUrl);

            $currentUrl = $this->url->getCurrentUrl();
            
            $currentUrl = ltrim($currentUrl, '/');
            $currentUrl = rtrim($currentUrl, '/');
            
            foreach ($urlArray as $myUrl) {
                $myUrl = rtrim($myUrl, "\n");
                $myUrl = rtrim($myUrl, "\r");
                $myUrl = rtrim($myUrl, " ");
                $myUrl = ltrim($myUrl, "\n");
                $myUrl = ltrim($myUrl, "\r");
                $myUrl = ltrim($myUrl, ' ');
                $myUrl = ltrim($myUrl, '/');
                if ($myUrl == $currentUrl) {
                    $count++;
                }
            }
        }
        
        //If current URL is'nt Default URL, return False.
        if ($count == 0) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * @return bool
     */
    protected function checkIsUrl()
    {
        $count = 0;
        //Get config Url Disable
        $restrictionUrl = $this->dataHelper->restrictionUrl($this->getStoreId());

        if ($restrictionUrl != null && $restrictionUrl != '') {
            $urlArray = explode("\n", $restrictionUrl);
            $currentUrl = $this->url->getCurrentUrl();

            $currentPath = $this->request->getOriginalPathInfo();
            $currentPath = ltrim($currentPath, '/');
            $currentPath = rtrim($currentPath, '/');
            if (strpos($currentPath, '?') !== false) {
                $currentPath = strstr($currentPath, '?', true);
            }
            
            foreach ($urlArray as $myUrl) {
                $myUrl = rtrim($myUrl, "\n");
                $myUrl = rtrim($myUrl, "\r");
                $myUrl = rtrim($myUrl, " ");
                $myUrl = ltrim($myUrl, "\n");
                $myUrl = ltrim($myUrl, "\r");
                $myUrl = ltrim($myUrl, ' ');
                $myUrl = ltrim($myUrl, '/');
                if ($myUrl == $currentPath) {
                    $count++;
                }
            }
        }
        
        if ($count == 0) {
            return true;
        } else {
            return false;
        }
    }
}
