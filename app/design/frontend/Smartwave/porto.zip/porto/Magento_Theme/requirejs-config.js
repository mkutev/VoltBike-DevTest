var config = {
   paths: {
        'instagramfeed': 'Magento_Theme/js/instashow/elfsight-instagram-feed'
    },
    shim: {
        'instagramfeed': {
            'deps': ['jquery']
        }
    }
};