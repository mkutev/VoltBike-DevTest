<?php
/**
 * BSS Commerce Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://bsscommerce.com/Bss-Commerce-License.txt
 *
 * @category   BSS
 * @package    Bss_GeoIPAutoSwitchStore
 * @author     Extension Team
 * @copyright  Copyright (c) 2016-2017 BSS Commerce Co. ( http://bsscommerce.com )
 * @license    http://bsscommerce.com/Bss-Commerce-License.txt
 */
namespace Bss\GeoIPAutoSwitchStore\Helper;

use Magento\Store\Model\ScopeInterface;
use Bss\GeoIPAutoSwitchStore\Model\Config\Source\TimeCookie;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @var string
     */
    public $scopeStore = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
    
    const GEOIP_ENABLE = 'bss_geoip/general/enable';
    const GEOIP_COUNTRIES = 'bss_geoip/general/country';
    const GEOIP_URL = 'bss_geoip/general/restriction_url';
    const RESTRICTIONU_USER_AGENT = 'bss_geoip/general/restriction_user_agent';
    const RESTRICTION_IP = 'bss_geoip/general/restriction_ip';
    const DEFAULT_REDIRECT = 'bss_geoip/general/default_redirect';
    const GEOIP_COUNTRIES_BLACK_LIST = 'bss_geoip/black_list/country';
    const GEOIP_URL_BLACK_LIST = 'bss_geoip/black_list/url';
    const GEOIP_ENABLE_BLACK_LIST = 'bss_geoip/black_list/enable';
    const GEOIP_IP_BLACK_LIST = 'bss_geoip/black_list/ip';
    const GEOIP_ALLOW_SWITCH = 'bss_geoip/general/allow_switch';
    const GEOIP_IP_FOR_TESTER = 'bss_geoip/general/tester_ip';
    const GEOIP_TIME_COOKIE = 'bss_geoip/general/time_cookie';
    const GEOIP_REDIRECT_SCOPE = 'bss_geoip/general/redirect_scope';
    const GEOIP_ENABLE_COOKIE = 'bss_geoip/general/enable_cookie';
    const GEOIP_URL_CUSTOM = 'bss_geoip_update/update/file_url';
    const GEOIP_FILE_CUSTOM = 'bss_geoip_update/update/file_upload';
    const GEOIP_URL_CUSTOM_IPV6 = 'bss_geoip_update/update_ipv6/file_url_ipv6';
    const GEOIP_FILE_CUSTOM_IPV6 = 'bss_geoip_update/update_ipv6/file_upload_ipv6';
    const WEB_URL_USE_STORE = 'web/url/use_store';

    /**
     * Data constructor.
     * @param \Magento\Framework\App\Helper\Context $context
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\App\Request\Http $request
    ) {
        parent::__construct($context);
        $this->request = $request;
        $this->scopeConfig = $context->getScopeConfig();
    }

    /**
     * @return mixed
     */
    public function getEnableModule()
    {
        return $this->scopeConfig->getValue(
            self::GEOIP_ENABLE,
            ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * @param string $storeId
     * @return mixed
     */
    public function getCountries($storeId)
    {
        return $this->scopeConfig->getValue(
            self::GEOIP_COUNTRIES,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    /**
     * @param string $storeId
     * @return mixed
     */
    public function restrictionUrl($storeId)
    {
        return $this->scopeConfig->getValue(
            self::GEOIP_URL,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }


    /**
     * @param string $storeId
     * @return mixed
     */
    public function getDefaultRedirect($storeId)
    {
        return $this->scopeConfig->getValue(
            self::DEFAULT_REDIRECT,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }


    /**
     * @param string $storeId
     * @return mixed
     */
    public function getUrlCustom()
    {
        $result = $this->scopeConfig->getValue(self::GEOIP_URL_CUSTOM, $this->scopeStore);
        return $result;
    }

    /**
     * @param string $storeId
     * @return mixed
     */
    public function getFileCustom()
    {
        $result = $this->scopeConfig->getValue(self::GEOIP_FILE_CUSTOM, $this->scopeStore);
        return $result;
    }

    /**
     * @param string $storeId
     * @return mixed
     */
    public function getUrlCustomIPv6()
    {
        $result = $this->scopeConfig->getValue(self::GEOIP_URL_CUSTOM_IPV6, $this->scopeStore);
        return $result;
    }

    /**
     * @param string $storeId
     * @return mixed
     */
    public function getFileCustomIPv6()
    {
        $result = $this->scopeConfig->getValue(self::GEOIP_FILE_CUSTOM_IPV6, $this->scopeStore);
        return $result;
    }

    /**
     * @param string $storeId
     * @return mixed
     */
    public function getUseStoreCode()
    {
        $result = $this->scopeConfig->isSetFlag(self::WEB_URL_USE_STORE, $this->scopeStore);
        return $result;
    }


    /**
     * @param string $storeId
     * @return mixed
     */
    public function restrictionUserAgent($storeId)
    {
        return $this->scopeConfig->getValue(
            self::RESTRICTIONU_USER_AGENT,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    /**
     * @param string $storeId
     * @return mixed
     */
    public function restrictionIp($storeId)
    {
        return $this->scopeConfig->getValue(
            self::RESTRICTION_IP,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    /**
     * @param string $storeId
     * @return mixed
     */
    public function getCountriesBlackList($storeId)
    {
        return $this->scopeConfig->getValue(
            self::GEOIP_COUNTRIES_BLACK_LIST,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    /**
     * @param string $storeId
     * @return mixed
     */
    public function getUrlBlackList($storeId)
    {
        return $this->scopeConfig->getValue(
            self::GEOIP_URL_BLACK_LIST,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    /**
     * @param string $storeId
     * @return mixed
     */
    public function getEnableBlackList($storeId)
    {
        return $this->scopeConfig->getValue(
            self::GEOIP_ENABLE_BLACK_LIST,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    /**
     * @param string $storeId
     * @return mixed
     */
    public function getIpBlackList($storeId)
    {
        return $this->scopeConfig->getValue(
            self::GEOIP_IP_BLACK_LIST,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    /**
     * @param string $storeId
     * @return mixed
     */
    public function getAllowSwitch($storeId)
    {
        return $this->scopeConfig->getValue(
            self::GEOIP_ALLOW_SWITCH,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    /**
     * @param string $storeId
     * @return mixed
     */
    public function getIpForTester($storeId)
    {
        return $this->scopeConfig->getValue(
            self::GEOIP_IP_FOR_TESTER,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    /**
     * @param string $storeId
     * @return mixed|string
     */
    public function getTimeCookie($storeId)
    {
        $result = $this->scopeConfig->getValue(
            self::GEOIP_TIME_COOKIE,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
        if ($result == null || $result == '') {
            $result = TimeCookie::ONE_MONTH_TO_SECOND;
        }
        return $result;
    }

    /**
     * @param string $storeId
     * @return mixed
     */
    public function getRedirectsScope($storeId)
    {
        return $this->scopeConfig->getValue(
            self::GEOIP_REDIRECT_SCOPE,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    /**
     * @param $storeId
     * @return mixed
     */
    public function getEnableCookie($storeId)
    {
        return $this->scopeConfig->getValue(
            self::GEOIP_ENABLE_COOKIE,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    public function getIpCustomer($ipForTester)
    {
        //If IP For Tester NULL then return current IP of Customer
        $ipCustomer = '';
        if ($ipForTester == null || $ipForTester == '') {
            $ipCustomers = explode(',',$this->getIpAdress());
            if (!empty($ipCustomers)) {
                $ipCustomer = $ipCustomers[0];
            }
        } else {
            $ipCustomer = $ipForTester;
        }
        if ($ipCustomer == '127.0.0.1' || $ipCustomer == 'UNKNOWN') {
            //Return a US IP
            $ipCustomer = '93.188.164.248';
        }
        return $ipCustomer;
    }

    /**
     * @return string
     */
    protected function getIpAdress()
    {
        $ipaddress = '';
        if ($this->request->getServer('HTTP_CLIENT_IP')) {
            $ipaddress = $this->request->getServer('HTTP_CLIENT_IP');
        } else if ($this->request->getServer('HTTP_X_FORWARDED_FOR')) {
            $ipaddress = $this->request->getServer('HTTP_X_FORWARDED_FOR');
        } else if ($this->request->getServer('HTTP_X_FORWARDED')) {
            $ipaddress = $this->request->getServer('HTTP_X_FORWARDED');
        } else if ($this->request->getServer('HTTP_FORWARDED_FOR')) {
            $ipaddress = $this->request->getServer('HTTP_FORWARDED_FOR');
        } else if ($this->request->getServer('HTTP_FORWARDED')) {
            $ipaddress = $this->request->getServer('HTTP_FORWARDED');
        } else if ($this->request->getServer('REMOTE_ADDR')) {
            $ipaddress = $this->request->getServer('REMOTE_ADDR');
        } else {
            $ipaddress = 'UNKNOWN';
        }

        return $ipaddress;
    }
}
