<?php
/**
 * BSS Commerce Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://bsscommerce.com/Bss-Commerce-License.txt
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This package designed for Magento COMMUNITY edition
 * BSS Commerce does not guarantee correct work of this extension
 * on any other Magento edition except Magento COMMUNITY edition.
 * BSS Commerce does not provide extension support in case of
 * incorrect edition usage.
 * =================================================================
 *
 * @category  BSS
 * @package   Bss_MultiStoreViewPricing
 * @author    Extension Team
 * @copyright Copyright (c) 2016-2017 BSS Commerce Co. ( http://bsscommerce.com )
 * @license   http://bsscommerce.com/Bss-Commerce-License.txt
 */
namespace Bss\MultiStoreViewPricingTierPrice\Model\ResourceModel\Product\Attribute\Backend;

use Magento\Catalog\Model\ResourceModel\Product\Attribute\Backend\GroupPrice\AbstractGroupPrice;

/**
 * Catalog product tier price backend attribute model
 *
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Tierprice extends AbstractGroupPrice
{
    /**
     * Initialize connection and define main table
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('catalog_product_entity_tier_price_store', 'value_id');
    }

    /**
     * Add qty column
     *
     * @param array $columns
     * @return array
     */
    protected function _loadPriceDataColumns($columns)
    {
        $columns = parent::_loadPriceDataColumns($columns);
        $columns['price_qty'] = 'qty';
        return $columns;
    }

    /**
     * Order by qty
     *
     * @param \Magento\Framework\DB\Select $select
     * @return \Magento\Framework\DB\Select
     */
    protected function _loadPriceDataSelect($select)
    {
        $select->order('qty');
        return $select;
    }

    /**
     * Load Tier Prices for product
     *
     * @param int $productId
     * @param int $websiteId
     * @return array
     */
    public function loadPriceData($productId, $storeId = null)
    {
        $connection = $this->getConnection();

        $columns = [
            'price_id' => $this->getIdFieldName(),
            'store_id' => 'store_id',
            'all_groups' => 'all_groups',
            'cust_group' => 'customer_group_id',
            'price' => 'value',
        ];

        $columns = $this->_loadPriceDataColumns($columns);

        $productIdFieldName = 'entity_id';
        $select = $connection->select()
            ->from($this->getMainTable(), $columns)
            ->where("{$productIdFieldName} = ?", $productId);

        $this->_loadPriceDataSelect($select);

        if ($storeId !== null) {
            if($storeId != 0)
                $select->where('store_id = ?', $storeId);
        }

        return $connection->fetchAll($select);
    }

    /**
     * Delete Tier Prices for product
     *
     * @param int $productId
     * @param int $websiteId
     * @param int $priceId
     * @return int The number of affected rows
     */
    public function deletePriceData($productId, $websiteId = null, $priceId = null)
    {
        $connection = $this->getConnection();

        $conds = [$connection->quoteInto('entity_id' . ' = ?', $productId)];

        if ($websiteId !== null) {
            $conds[] = $connection->quoteInto('store_id = ?', $websiteId);
        }

        if ($priceId !== null) {
            $conds[] = $connection->quoteInto($this->getIdFieldName() . ' = ?', $priceId);
        }

        $where = implode(' AND ', $conds);

        return $connection->delete($this->getMainTable(), $where);
    }

    /**
     * @param $productId
     * @param $storeId
     * @param null $attributeId
     * @return null|string
     */
    public function getTierPriceConfigForStore($productId, $storeId, $attributeId = null)
    {
        if($attributeId == null) return null;
        $connection = $this->getConnection();

        $columns = [
            'value' => 'value',
        ];

        $productIdFieldName = $this->getProductIdFieldName();
        $select = $connection->select()
            ->from($this->getTable('catalog_product_entity_int'), $columns)
            ->where("{$productIdFieldName} = ?", $productId)
            ->where("attribute_id = ?", $attributeId);
        $select->where('store_id IN(?)', [0, $storeId]);
        $select->order('store_id desc');
        return $connection->fetchOne($select);
    }
}
