<?php
namespace Bss\MultiStoreViewPricingTierPrice\Block\Swatches\Product\Renderer;

use Magento\Catalog\Block\Product\Context;
use Magento\Catalog\Helper\Product as CatalogProduct;
use Magento\ConfigurableProduct\Helper\Data;
use Magento\ConfigurableProduct\Model\ConfigurableAttributeData;
use Magento\Customer\Helper\Session\CurrentCustomer;
use Magento\Framework\Json\EncoderInterface;
use Magento\Framework\Pricing\PriceCurrencyInterface;
use Magento\Framework\Stdlib\ArrayUtils;
use Magento\Swatches\Helper\Data as SwatchData;
use Magento\Swatches\Helper\Media;
use Magento\Swatches\Model\SwatchAttributesProvider;
use Bss\MultiStoreViewPricingTierPrice\Model\ResourceModel\Product\Attribute\Backend\Tierprice;
use \Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Locale\Format;
use Bss\MultiStoreViewPricing\Helper\Data as MultiStoreViewHelper;

class Configurable extends \Magento\Swatches\Block\Product\Renderer\Configurable
{
    /**
     * @var Format
     */
    private $localeFormat;

    /**
     * @var Tierprice
     */
    private $tierPrice;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var \Magento\Framework\EntityManager\MetadataPool
     */
    private $metadataPool;

    /**
     * @var MultiStoreViewHelper
     */
    private $multiStoreViewHelper;

    /**
     * @param Context $context
     * @param ArrayUtils $arrayUtils
     * @param EncoderInterface $jsonEncoder
     * @param Data $helper
     * @param CatalogProduct $catalogProduct
     * @param CurrentCustomer $currentCustomer
     * @param PriceCurrencyInterface $priceCurrency
     * @param ConfigurableAttributeData $configurableAttributeData
     * @param SwatchData $swatchHelper
     * @param Media $swatchMediaHelper
     * @param Tierprice $tierPrice
     * @param StoreManagerInterface $storeManager
     * @param \Magento\Framework\EntityManager\MetadataPool $metadataPool
     * @param Format $localeFormat
     * @param MultiStoreViewHelper $multiStoreViewHelper
     * @param array $data
     * @param SwatchAttributesProvider|null $swatchAttributesProvider
     */
    public function __construct(
        Context $context,
        ArrayUtils $arrayUtils,
        EncoderInterface $jsonEncoder,
        Data $helper,
        CatalogProduct $catalogProduct,
        CurrentCustomer $currentCustomer,
        PriceCurrencyInterface $priceCurrency,
        ConfigurableAttributeData $configurableAttributeData,
        SwatchData $swatchHelper,
        Media $swatchMediaHelper,
        Tierprice $tierPrice,
        StoreManagerInterface $storeManager,
        \Magento\Framework\EntityManager\MetadataPool $metadataPool,
        Format $localeFormat,
        MultiStoreViewHelper $multiStoreViewHelper,
        array $data = [],
        SwatchAttributesProvider $swatchAttributesProvider = null
    ) {
        $this->localeFormat = $localeFormat;
        $this->tierPrice = $tierPrice;
        $this->storeManager = $storeManager;
        $this->metadataPool = $metadataPool;
        $this->multiStoreViewHelper = $multiStoreViewHelper;
        parent::__construct(
            $context,
            $arrayUtils,
            $jsonEncoder,
            $helper,
            $catalogProduct,
            $currentCustomer,
            $priceCurrency,
            $configurableAttributeData,
            $swatchHelper,
            $swatchMediaHelper,
            $data,
            $swatchAttributesProvider
        );
    }

    /**
     * @return array
     * @throws \Exception
     */
    protected function getOptionPrices()
    {
        $prices = [];
        foreach ($this->getAllowProducts() as $product) {
            $tierPrices = [];
            $priceInfo = $product->getPriceInfo();
            $tierPriceModel =  $priceInfo->getPrice('tier_price');
            $tierPricesList = $tierPriceModel->getTierPriceList();
            foreach ($tierPricesList as $tierPrice) {
                $tierPrices[] = [
                    'qty' => $this->localeFormat->getNumber($tierPrice['price_qty']),
                    'price' => $this->localeFormat->getNumber($tierPrice['price']->getValue()),
                    'percentage' => $this->localeFormat->getNumber(
                        $tierPriceModel->getSavePercent($tierPrice['price'])
                    ),
                ];
            }

            if ($this->multiStoreViewHelper->getTierPriceConfig() == 1) {
                $tierPrices = [];
            } else {
                $tier_config = $product->getResource()->getAttributeRawValue(
                    $product->getId(),
                    'tier_price_config_for_store',
                    $product->getStoreId()
                );

                if($tier_config == 1) {
                    $tierPrices = [];
                }
            }

            $resource = $this->tierPrice;
            $tierDatas = $resource->loadPriceData(
                $product->getData($this->metadataPool->getMetadata(\Magento\Catalog\Api\Data\ProductInterface::class)->getLinkField()),
                $this->storeManager->getStore()->getId()
            );
            foreach ($tierDatas as $k => $v) {
                $tierPrices[] = [
                    'qty' => $this->localeFormat->getNumber($v['price_qty']),
                    'price' => $this->localeFormat->getNumber($v['price']),
                    'percentage' => $this->localeFormat->getNumber(
                        $this->getSavePercent(
                            $priceInfo->getPrice(
                                \Magento\Catalog\Pricing\Price\FinalPrice::PRICE_CODE
                            )->getAmount()->getValue(),
                            $v['price']
                        )
                    ),
                ];
            }

            $prices[$product->getId()] =
                [
                    'oldPrice' => [
                        'amount' => $this->localeFormat->getNumber(
                            $priceInfo->getPrice('regular_price')->getAmount()->getValue()
                        ),
                    ],
                    'basePrice' => [
                        'amount' => $this->localeFormat->getNumber(
                            $priceInfo->getPrice('final_price')->getAmount()->getBaseAmount()
                        ),
                    ],
                    'finalPrice' => [
                        'amount' => $this->localeFormat->getNumber(
                            $priceInfo->getPrice('final_price')->getAmount()->getValue()
                        ),
                    ],
                    'tierPrices' => $tierPrices,
                ];
        }
        return $prices;
    }

    /**
     * @param float $productPrice
     * @param float $amount
     * @return float
     */
    protected function getSavePercent($productPrice, $amount)
    {
        return round(
            100 - ((100 / $productPrice) * $amount)
        );
    }
}
