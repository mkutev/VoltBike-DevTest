<?php
namespace Magehit\Storelocator\Helper;
use Magento\Store\Model\ScopeInterface;
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    const XML_PATH_STORE = 'store_locator/';
    protected $_backendUrl;
    protected $storeManager;
    protected $request;
    protected $assetRepo;
    //protected $_scopeConfig;

    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Backend\Model\UrlInterface $backendUrl,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\App\RequestInterface  $RequestInterface,
        \Magento\Framework\View\Asset\Repository $Repository

    ) {
        parent::__construct($context);
        $this->_backendUrl = $backendUrl;
        $this->storeManager = $storeManager;
        $this->request = $RequestInterface;
        $this->assetRepo = $Repository;
    }

    public function getProductsGridUrl()
    {
        return $this->_backendUrl->getUrl('magehit_storelocator/contacts/products', ['_current' => true]);
    }
    public function getConfigValue($field, $storeId = null)
    {
        return $this->scopeConfig->getValue(
            $field, ScopeInterface::SCOPE_STORE, $storeId
        );
    }
    
    public function getUrlimage($path){
        return $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA) . $path;
    }
   

    public function getConfig($code, $storeId = null)
    {

        return $this->getConfigValue(self::XML_PATH_STORE . $code, $storeId);
    }
    public function getEnable($storeId = null)
    {

        return $this->getConfigValue(self::XML_PATH_STORE . 'general/enable', $storeId);
    }
    public function getIdentifier($storeId = null){
         return $this->getConfigValue(self::XML_PATH_STORE . 'general/url', $storeId);
    }
    
    public function getUrlSuffix($storeId = null){
         return $this->getConfigValue(self::XML_PATH_STORE . 'general/suffix', $storeId);    
    }
    public function getSendto(){
        return $this->getConfigValue('trans_email/ident_general/email');
        
    }
    public function getSender(){
        return $this->getConfigValue('trans_email/ident_general/name');
        
    }
    public function getUrlstore($path,$storeId = null){
        return $this->storeManager->getStore()->getBaseUrl().$this->getIdentifier($storeId).'/'.$path;
    }
    public function getLink(){
        $path = trim($this->getConfig( 'general/url',$this->storeManager->getStore()->getId())).trim($this->getConfig( 'general/suffix',$this->storeManager->getStore()->getId()));
        return $this->storeManager->getStore()->getBaseUrl().$path;
    }
    public function getLabel(){
        return trim($this->getConfig( 'general/label_link',$this->storeManager->getStore()->getId()));
         
    }

    public function getDefaultimage(){
        if(trim($this->getConfig( 'general/logo',$this->storeManager->getStore()->getId())) != ''){
            return $this->getUrlimage('storelocator/'.trim($this->getConfig( 'general/logo',$this->storeManager->getStore()->getId())));
        }
        $params = array('_secure' => $this->request->isSecure());
        return $this->assetRepo->getUrlWithParams('Magehit_Storelocator::images/store.png', $params);
       
    }
    public function getMaxradius(){
        $max = (int)trim($this->getConfig( 'radius/max',$this->storeManager->getStore()->getId()));
        if(!$max){
            return 100;
        }else{
            return $max;
        }
    }
   
}