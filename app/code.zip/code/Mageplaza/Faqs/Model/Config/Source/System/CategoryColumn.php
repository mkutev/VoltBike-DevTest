<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Faqs
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Faqs\Model\Config\Source\System;

use Magento\Framework\Option\ArrayInterface;

/**
 * Class CategoryColumn
 * @package Mageplaza\Faqs\Model\Config\Source\System
 */
class CategoryColumn implements ArrayInterface
{
    const ONE_COLUMN   = 1;
    const TWO_COLUMN   = 2;
    const THREE_COLUMN = 3;

    /**
     * @return array
     */
    public function toOptionArray()
    {
        $options = [];
        foreach ($this->toArray() as $value => $label) {
            $options[] = [
                'value' => $value,
                'label' => $label
            ];
        }

        return $options;
    }

    /**
     * Get options in "key-value" format
     *
     * @return array
     */
    public function toArray()
    {
        return [self::ONE_COLUMN => __('1'), self::TWO_COLUMN => __('2'), self::THREE_COLUMN => __('3')];
    }
}
