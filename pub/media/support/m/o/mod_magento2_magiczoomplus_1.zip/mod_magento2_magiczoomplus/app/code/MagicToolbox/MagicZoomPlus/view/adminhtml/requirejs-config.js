
var config = {
    map: {
        '*': {
            magiczoomplus: 'MagicToolbox_MagicZoomPlus/js/script'
        }
    }
};
