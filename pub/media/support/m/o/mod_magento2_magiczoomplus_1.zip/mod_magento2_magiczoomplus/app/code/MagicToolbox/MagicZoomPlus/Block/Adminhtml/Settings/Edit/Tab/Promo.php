<?php

namespace MagicToolbox\MagicZoomPlus\Block\Adminhtml\Settings\Edit\Tab;

/**
 * Promo tab
 *
 */
class Promo extends \Magento\Backend\Block\Template
{
    /**
     * @var string
     */
    protected $_template = 'MagicToolbox_MagicZoomPlus::promo.phtml';
}
