#######################################################

 Magic Zoom Plus™
 Magento 2 module version v1.5.48 [v1.6.79:v5.2.10]
 
 www.magictoolbox.com
 support@magictoolbox.com

 Copyright 2019 Magic Toolbox

#######################################################

INSTALLATION:

1. Unzip the Magic Zoom Plus extension for Magento 2.0.

2. Upload the 'app' folder to your Magento directory.

3. Login to the Magento Admin as an administrator.

4. Click [System > Web Setup Wizard] in the menu.

5. Click the [Component Manager] link.

6. Find the Magic Zoom Plus extension in the list and select the [Enable] action.

7. Follow the instructions in the wizard until the process is complete (you will see 'Success' message).    

8. Adjust the Magic Zoom Plus settings to suit your needs - go to the [Magic Toolbox > Magic Zoom Plus] menu in the Magento admin panel.

9. Magic Zoom Plus is ready to use!

10. To upgrade your version of Magic Zoom Plus (which removes the "Please upgrade" text), buy Magic Zoom Plus and overwrite the app/code/MagicToolbox/MagicZoomPlus/view/frontend/web/js/magiczoomplus.js file file with the new one in your licensed version.

Buy a single license here:

http://www.magictoolbox.com/buy/magiczoomplus/

