var config = {
    map: {
        '*': {
            voiceSearch: 'V2Agency_Ajaxsearch/js/voiceSearch',
            bindEvents: 'V2Agency_Ajaxsearch/js/bindEvents',
            dataProvider: 'V2Agency_Ajaxsearch/js/dataProvider',
            voiceEvents: 'V2Agency_Ajaxsearch/js/voiceEvents'
        }
    }
};