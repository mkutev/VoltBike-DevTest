<?php
/**
 * Copyright © 2019 V2Agency . All rights reserved.
 * 
 */
namespace V2Agency\Ajaxsearch\Model\Search;
use \V2Agency\Ajaxsearch\Helper\Data as HelperData;
use \Magento\Search\Helper\Data as SearchHelper;
use \Magento\Cms\Model\ResourceModel\Page\CollectionFactory as PageCollection;
use \Magento\Framework\ObjectManagerInterface as ObjectManager;
use \Magento\Search\Model\QueryFactory;
use \V2Agency\Ajaxsearch\Model\Source\AutocompleteFields;
use \V2Agency\Ajaxsearch\Model\Source\ProductFields;
/**
 * Product model. Return product data used in search autocomplete
 */
class Page implements \V2Agency\Ajaxsearch\Model\SearchInterface
{
    /**
     * @var \Magehit\Ajaxsearch\Helper\Data
     */
    protected $helperData;
    /**
     * @var \Magento\Search\Helper\Data
     */
    protected $searchHelper;
	/**
     * @var \Magento\Cms\Model\ResourceModel\Page\CollectionFactory
     */
    protected $pageCollection;
    /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $objectManager;
    /**
     * @var \Magento\Search\Model\QueryFactory
     */
    private $queryFactory;
    /**
     * Product constructor.
     *
     * @param HelperData $helperData
     * @param SearchHelper $searchHelper
     * @param ObjectManager $objectManager
     * @param QueryFactory $queryFactory
     */
    public function __construct(
        HelperData $helperData,
        SearchHelper $searchHelper,
        ObjectManager $objectManager,
        QueryFactory $queryFactory,
		PageCollection $pageCollection
    ) {
        $this->helperData = $helperData;
        $this->searchHelper = $searchHelper;
        $this->objectManager = $objectManager;
        $this->queryFactory = $queryFactory;
		$this->pageCollection = $pageCollection;
    }
    /**
     * {@inheritdoc}
     */
    public function getResponseData($param = array())
    {
        $responseData['code'] = AutocompleteFields::PAGE;
        $responseData['data'] = [];
        if (!$this->canAddToResult()) {
            return $responseData;
        }
        $queryText = $this->queryFactory->get()->getQueryText();
        $cmsCollection = $this->getCmsCollection($queryText);
		
        foreach ($cmsCollection as $page) {
            $responseData['data'][] = $this->getCmsData($page);
        }
        return $responseData;
    }
	
    /**
     * Retrive product collection by query text
     *
     * @param  string $queryText
     * @return mixed
     */
    protected function getCmsCollection($queryText)
    {
        $resultNumber = $this->helperData->getPageResultNumber();
        $cmsCollection = $this->pageCollection->create();
		$cmsCollection->addFieldToFilter('is_active', \Magento\Cms\Model\Page::STATUS_ENABLED);
		$cmsCollection->addFieldToFilter(
			'title', array('like'=> '%' . $queryText .'%')
		);
        $cmsCollection->getSelect()->limit($resultNumber);
        return $cmsCollection;
    }
    /**
     * Retrieve all product data
     *
     * @param \Magento\Catalog\Model\Product $product
     * @return array
     */
    protected function getCmsData($page)
    {
        return array(
			'title' => $page->getTitle(),
			'url' => $this->helperData->getUrlBilder($page->getIdentifier())
		);
    }
    /**
     * {@inheritdoc}
     */
    public function canAddToResult()
    {
        return in_array(AutocompleteFields::PAGE, $this->helperData->getAutocompleteFieldsAsArray());
    }
}