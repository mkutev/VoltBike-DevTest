<?php
/**
 * Copyright © 2019 V2Agency . All rights reserved.
 * 
 */
namespace V2Agency\Ajaxsearch\Model;
use Magento\Framework\ObjectManagerInterface as ObjectManager;
/**
 * SearchFactory class for Search model
 */
class SearchFactory
{
    /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $objectManager = null;
    /**
     * @var string
     */
    protected $map;
    /**
     * Factory constructor
     *
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     * @param array $map
     */
    public function __construct(
        ObjectManager $objectManager,
        array $map = []
    ) {
        $this->objectManager = $objectManager;
        $this->map = $map;
    }
    /**
     *
     * @param string $param
     * @param array $arguments
     * @return \V2Agency\Ajaxsearch\Model\SearchInterface
     * @throws \UnexpectedValueException
     */
    public function create($param, array $arguments = [])
    {
        if (isset($this->map[$param])) {
            $instance = $this->objectManager->create($this->map[$param], $arguments);
        } else {
            $instance = $this->objectManager->create('\V2Agency\Ajaxsearch\Model\Search\Suggested', $arguments);
        }
        if (!$instance instanceof \V2Agency\Ajaxsearch\Model\SearchInterface) {
            throw new \UnexpectedValueException(
                'Class ' . get_class($instance) . ' should be an instance of \V2Agency\Ajaxsearch\Model\SearchInterface'
            );
        }
        return $instance;
    }
}