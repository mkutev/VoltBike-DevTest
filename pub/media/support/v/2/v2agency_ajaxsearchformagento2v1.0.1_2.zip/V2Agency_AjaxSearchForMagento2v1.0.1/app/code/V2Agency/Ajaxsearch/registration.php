<?php
/**
 * Copyright © 2019 V2Agency. All rights reserved.
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'V2Agency_Ajaxsearch',
    __DIR__
);