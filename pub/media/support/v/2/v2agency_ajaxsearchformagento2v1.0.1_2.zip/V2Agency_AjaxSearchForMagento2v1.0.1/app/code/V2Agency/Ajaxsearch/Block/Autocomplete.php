<?php
/**
 * Copyright © 2019 V2Agency . All rights reserved.
 * 
 */
namespace V2Agency\Ajaxsearch\Block;
/**
 * Autocomplete class used to paste config data
 */
class Autocomplete extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \V2Agency\Ajaxsearch\Helper\Data
     */
    protected $helperData;
    /**
     * Autocomplete constructor.
     *
     * @param \V2Agency\Ajaxsearch\Helper\Data $helperData
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param array $data
     */
    public function __construct(
        \V2Agency\Ajaxsearch\Helper\Data $helperData,
        \Magento\Framework\View\Element\Template\Context $context,
        array $data = []
    ) {
    
        $this->helperData = $helperData;
        parent::__construct($context, $data);
    }
    public function getSearchDelay()
    {
        return $this->helperData->getSearchDelay();
    }
	
    public function getLoadingIcon()
    {
        return $this->helperData->getLoadingIcon();
    }
    /**
     * Retrieve search action url
     *
     * @return string
     */
    public function getSearchUrl()
    {
        return $this->getUrl("v2agency_ajaxsearch/ajax/index");
    }
}