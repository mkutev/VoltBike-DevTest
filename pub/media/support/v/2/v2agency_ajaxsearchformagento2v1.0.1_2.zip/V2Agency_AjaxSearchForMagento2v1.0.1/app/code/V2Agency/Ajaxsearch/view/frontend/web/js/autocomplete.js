define([
    'jquery',
    'uiComponent',
    'ko'
], function($, Component, ko) {
    'use strict';


    return Component.extend({
        defaults: {
            template: 'V2Agency_Ajaxsearch/autocomplete',
            addToCartFormSelector: '[data-role=searchsuiteautocomplete-tocart-form]',
            showPopup: ko.observable(false),
            result: {
                suggest: {
                    data: ko.observableArray([])
                },
                product: {
                    data: ko.observableArray([]),
                    size: ko.observable(0),
                    url: ko.observable('')
                },
                page: {
                    data: ko.observableArray([])
                },
                categories: {
                    data: ko.observableArray([])
                },
                dataconfig: {
                    header: ko.observable([]),
                    footer: ko.observable([])
                }
            },
            anyResultCount: false
        },


        initialize: function() {
            var self = this;
            this._super();

            this.anyResultCount = ko.computed(function() {
                var sum = self.result.suggest.data().length + self.result.product.data().length + self.result.page.data().length + self.result.categories.data().length;
                if (sum > 0) {
                    return true;
                }
                return false;
            }, this);
        },

    });
});