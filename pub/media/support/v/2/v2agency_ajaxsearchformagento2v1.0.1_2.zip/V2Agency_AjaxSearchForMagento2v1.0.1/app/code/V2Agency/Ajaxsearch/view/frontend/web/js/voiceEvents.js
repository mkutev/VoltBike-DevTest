define([
    'jquery',
    'uiComponent',
    'uiRegistry',
    'mageUtils'
], function($, Component, registry, utils) {
    'use strict';

    return Component.extend({
        defaults: {
            minSearchLength: 2
        },

        initialize: function() {
            this._super();
        },

        load: function(event) {
            var self = this;
            var searchText = $("#search, #mobile_search, .minisearch input[type=\"text\"]").val();
            var catId = $('#search_cat').find('option:selected').val();

            if (searchText.length < self.minSearchLength) {
                return false;
            }
            registry.get('searchsuiteautocompleteDataProvider', function(dataProvider) {
                dataProvider.searchText = searchText;
                dataProvider.catId = catId;
                dataProvider.load();
            });
        },

    });
});