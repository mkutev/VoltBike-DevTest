<?php
/**
 * Copyright © 2019 V2Agency . All rights reserved.
 * 
 */
namespace V2Agency\Ajaxsearch\Model\Source;
class SortFields
{
    const PRODUCTNAME = 'name';
    const PRODUCTPRICE = 'price';
	
    const PRODUCTSKU = 'sku';
    /**
     *
     * @return array
     */
    public function toOptionArray()
    {
        $this->options = [
            ['value' => self::PRODUCTNAME, 'label' => __('Product Name')],
            ['value' => self::PRODUCTPRICE, 'label' => __('Product Price')],
            ['value' => self::PRODUCTSKU, 'label' => __('Product SKU')],
        ];
   
        return $this->options;
    }
}