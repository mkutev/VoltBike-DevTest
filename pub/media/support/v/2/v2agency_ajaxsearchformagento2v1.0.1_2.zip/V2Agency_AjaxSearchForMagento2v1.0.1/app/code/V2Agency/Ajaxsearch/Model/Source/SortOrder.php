<?php
/**
 * Copyright © 2019 V2Agency . All rights reserved.
 * 
 */
namespace V2Agency\Ajaxsearch\Model\Source;
class SortOrder
{
    const ASCENDING = 'ASC';
    const DESCENDING = 'DESC';
    /**
     *
     * @return array
     */
    public function toOptionArray()
    {
        $this->options = [
            ['value' => self::ASCENDING, 'label' => __('Ascending')],
            ['value' => self::DESCENDING, 'label' => __('Descending')],
        ];
        return $this->options;
    }
}