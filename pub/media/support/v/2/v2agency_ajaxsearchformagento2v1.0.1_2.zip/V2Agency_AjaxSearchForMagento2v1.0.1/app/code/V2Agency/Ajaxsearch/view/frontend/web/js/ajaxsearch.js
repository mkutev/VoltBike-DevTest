require(['jquery'], function($) {
    $(document).ready(function() {
        $('label[data-role="minisearch-label"]').click(function() {
            $('.control, .mhsearch-categories').toggle();
        })
    });
});