<?php
/**
 * Copyright © 2019 V2Agency . All rights reserved.
 * 
 */
namespace V2Agency\Ajaxsearch\Model\Source;
class AutocompleteFields
{
    const SUGGEST = 'suggest';
    const PRODUCT = 'product';
    const PAGE = 'page';
    const CATEGORIES = 'categories';
    const DATACONFIG = 'dataconfig';
    /**
     *
     * @return array
     */
    public function toOptionArray()
    {
        $this->options = [
            /* ['value' => self::SUGGEST, 'label' => __('Suggested')], */
            ['value' => self::PRODUCT, 'label' => __('Products')],
            ['value' => self::PAGE, 'label' => __('Pages')],
            ['value' => self::CATEGORIES, 'label' => __('Categories')],
        ];
        return $this->options;
    }
}