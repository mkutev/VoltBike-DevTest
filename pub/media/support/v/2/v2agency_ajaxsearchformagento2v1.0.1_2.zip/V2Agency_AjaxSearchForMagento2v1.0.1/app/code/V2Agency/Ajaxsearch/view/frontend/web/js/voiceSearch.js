define([
    'jquery',
    'voiceEvents',
    'domReady!'
], function($, vE) {
    'use strict';
    var $voiceSearchTrigger = $(".icon_mic1");
    var $searchInput = $("#search");

    window.SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition || window.mozSpeechRecognition || window.msSpeechRecognition;
    // if (window.SpeechRecognition) {
    //     $(".voice-search").removeClass("icon_mic_show");
    // } else {
    //     alert('Your browser does not support SpeechRecognition'); return;
    // }

    $(".voice-search").removeClass("icon_mic_show");

    function _parseTranscript(e) {
        return Array.from(e.results).map(result => result[0]).map(result => result.transcript).join('').toString();
    }

    var recognition = new SpeechRecognition();
    recognition.onresult = (evt) => {
        $searchInput.attr("placeholder", '');
        var search_text = _parseTranscript(evt);
        $searchInput.val(search_text);

        if (evt.results[0].isFinal) {
            new vE().load();
            recognition.stop();
            $(".voice-search").removeClass("icon_mic2");
            $(".voice-search").addClass("icon_mic1");
            $(".voice-search").removeClass("waves");
            $(".ept-mobile").removeClass("iconMobile2");
            $(".ept-mobile").addClass("iconMobile1");
        }

    }

    recognition.onerror = (evt) => {
        if (evt.error == 'not-allowed') {
            console.log("I can't listen if you don't grant me permission :(");
            // alert("I can't listen if you don't grant me permission :(");
        } else {
            console.log(`Whoops I got an ${evt.error} error`);
            $searchInput.attr("placeholder", "Can't Recongnize Speech...");
        }
        $(".voice-search").removeClass("icon_mic2");
        $(".voice-search").addClass("icon_mic1");
        $(".voice-search").removeClass("waves");
        $(".ept-mobile").removeClass("iconMobile2");
        $(".ept-mobile").addClass("iconMobile1");
    }

    recognition.onstart = function() {
        $(".voice-search").removeClass("icon_mic1");
        $(".voice-search").addClass("icon_mic2");
        // $(".voice-search").removeClass("test123");
        $(".voice-search").addClass("waves");
        $(".ept-mobile").addClass("iconMobile2");
        $(".ept-mobile").removeClass("iconMobile1");
    };

    function startListening(e) {
        e.preventDefault();
        recognition.lang = window.storeLanguage;
        if ($searchInput.attr("placeholder") == "Listening...") {
            recognition.stop();
            console.log('stop listening');
            $(".voice-search").removeClass("icon_mic2");
            $(".voice-search").addClass("icon_mic1");
            $(".voice-search").removeClass("waves");
            $(".ept-mobile").removeClass("iconMobile2");
            $(".ept-mobile").addClass("iconMobile1");
            $searchInput.attr("placeholder", "Search text");
        } else {
            console.log('start listening');
            $searchInput.val('');
            recognition.start();
            $searchInput.attr("placeholder", "Listening...");
        }
    }


    return function() {
        $voiceSearchTrigger.on('click touch', startListening);
    }
});