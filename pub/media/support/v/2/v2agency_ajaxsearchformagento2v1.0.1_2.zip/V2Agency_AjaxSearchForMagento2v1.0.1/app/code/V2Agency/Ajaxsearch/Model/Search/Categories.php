<?php
/**
 * Copyright © 2019 V2Agency . All rights reserved.
 * 
 */
namespace V2Agency\Ajaxsearch\Model\Search;
use \V2Agency\Ajaxsearch\Helper\Data as HelperData;
use \Magento\Search\Helper\Data as SearchHelper;
use \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory as CategoriesCollection;
use \Magento\Framework\ObjectManagerInterface as ObjectManager;
use \Magento\Search\Model\QueryFactory;
use \V2Agency\Ajaxsearch\Model\Source\AutocompleteFields;
use \V2Agency\Ajaxsearch\Model\Source\ProductFields;
use \Magento\Store\Model\StoreManagerInterface as StoreManager;
/**
 * Product model. Return product data used in search autocomplete
 */
class Categories implements \V2Agency\Ajaxsearch\Model\SearchInterface
{
    /**
     * @var \V2Agency\Ajaxsearch\Helper\Data
     */
    protected $helperData;
    /**
     * @var \Magento\Search\Helper\Data
     */
    protected $searchHelper;
	/**
     * @var \Magento\Cms\Model\ResourceModel\Page\CollectionFactory
     */
    protected $catCollection;
    /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $objectManager;
    /**
     * @var \Magento\Search\Model\QueryFactory
     */
    private $queryFactory;
    private $storeManager;
    /**
     * Product constructor.
     *
     * @param HelperData $helperData
     * @param SearchHelper $searchHelper
     * @param ObjectManager $objectManager
     * @param QueryFactory $queryFactory
     */
    public function __construct(
        HelperData $helperData,
        SearchHelper $searchHelper,
        ObjectManager $objectManager,
        QueryFactory $queryFactory,
		CategoriesCollection $catCollection,
		StoreManager $storeManager
    ) {
        $this->helperData = $helperData;
        $this->searchHelper = $searchHelper;
        $this->objectManager = $objectManager;
        $this->queryFactory = $queryFactory;
		$this->catCollection = $catCollection;
		$this->storeManager = $storeManager;
    }
    /**
     * {@inheritdoc}
     */
    public function getResponseData($param = array())
    {
        $responseData['code'] = AutocompleteFields::CATEGORIES;
        $responseData['data'] = [];
        if (!$this->canAddToResult()) {
            return $responseData;
        }
        $queryText = $this->queryFactory->get()->getQueryText();
        $catCollection = $this->getCategoriesCollection($queryText);
        foreach ($catCollection as $cat) {
            $responseData['data'][] = $this->getCatData($cat);
        }
        return $responseData;
    }
    /**
     * Retrive product collection by query text
     *
     * @param  string $queryText
     * @return mixed
     */
    protected function getCategoriesCollection($queryText)
    {
        $resultNumber = $this->helperData->getCategoriesResultNumber();
        $catCollection = $this->catCollection->create()->addAttributeToSelect('*')->setStore($this->storeManager->getStore());
		$catCollection->addFieldToFilter('is_active', true);
		$catCollection->addFieldToFilter(
			'name', array('like'=> '%' . $queryText .'%')
		);
        $catCollection->getSelect()->limit($resultNumber);
        return $catCollection;
    }
    protected function getCatData($cat)
    {
        return array(
			'title' => $cat->getName(),
			'url' => $cat->getUrl()
		);
    }
    /**
     * {@inheritdoc}
     */
    public function canAddToResult()
    {
        return in_array(AutocompleteFields::CATEGORIES, $this->helperData->getAutocompleteFieldsAsArray());
    }
}
