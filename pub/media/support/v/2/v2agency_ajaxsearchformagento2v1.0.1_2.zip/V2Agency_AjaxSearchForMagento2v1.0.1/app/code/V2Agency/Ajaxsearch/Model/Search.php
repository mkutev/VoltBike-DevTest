<?php
/**
 * Copyright © 2019 V2Agency . All rights reserved.
 * 
 */
namespace V2Agency\Ajaxsearch\Model;
use \V2Agency\Ajaxsearch\Helper\Data as HelperData;
use \V2Agency\Ajaxsearch\Model\SearchFactory;
/**
 * Search class returns needed search data
 */
class Search
{
    /**
     * @var \V2Agency\Ajaxsearch\Helper\Data
     */
    protected $helperData;
    /**
     * @var \V2Agency\Ajaxsearch\Model\SearchFactory
     */
    protected $searchFactory;
    /**
     * Search constructor.
     * @param \V2Agency\Ajaxsearch\Model\SearchFactory $searchFactory
     */
    public function __construct(
        HelperData $helperData,
        SearchFactory $searchFactory
    ) {
        $this->helperData = $helperData;
        $this->searchFactory = $searchFactory;
    }
    /**
     * Retrieve suggested, product data
     *
     * @return array
     */
    public function getData($param = array())
    {
        $data = [];
        $autocompleteFields = $this->helperData->getAutocompleteFieldsAsArray();
		$autocompleteFields[] = 'dataconfig';
        foreach ($autocompleteFields as $field) {
			
           $data[] = $this->searchFactory->create($field)->getResponseData($param);
        }
        return $data;
    }
}