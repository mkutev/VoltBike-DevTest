<?php
/**
 * Copyright © 2019 V2Agency . All rights reserved.
 * 
 */
namespace V2Agency\Ajaxsearch\Model\Search;
use \V2Agency\Ajaxsearch\Helper\Data as HelperData;
use \Magento\Search\Helper\Data as SearchHelper;
use \Magento\Catalog\Model\Layer\Resolver as LayerResolver;
use \Magento\Framework\ObjectManagerInterface as ObjectManager;
use \Magento\Search\Model\QueryFactory;
use \V2Agency\Ajaxsearch\Model\Source\AutocompleteFields;
use \V2Agency\Ajaxsearch\Model\Source\ProductFields;
/**
 * Product model. Return product data used in search autocomplete
 */
class Product implements \V2Agency\Ajaxsearch\Model\SearchInterface
{
    /**
     * @var \V2Agency\Ajaxsearch\Helper\Data
     */
    protected $helperData;
    /**
     * @var \Magento\Search\Helper\Data
     */
    protected $searchHelper;
    /**
     * @var \Magento\Catalog\Model\Layer\Resolver
     */
    protected $layerResolver;
    /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $objectManager;
    /**
     * @var \Magento\Search\Model\QueryFactory
     */
    private $queryFactory;
    /**
     * Product constructor.
     *
     * @param HelperData $helperData
     * @param SearchHelper $searchHelper
     * @param LayerResolver $layerResolver
     * @param ObjectManager $objectManager
     * @param QueryFactory $queryFactory
     */
    public function __construct(
        HelperData $helperData,
        SearchHelper $searchHelper,
        LayerResolver $layerResolver,
        ObjectManager $objectManager,
        QueryFactory $queryFactory
    ) {
    
        $this->helperData = $helperData;
        $this->searchHelper = $searchHelper;
        $this->layerResolver = $layerResolver;
        $this->objectManager = $objectManager;
        $this->queryFactory = $queryFactory;
    }
    /**
     * {@inheritdoc}
     */
    public function getResponseData($param = array())
    {
        $responseData['code'] = AutocompleteFields::PRODUCT;
        $responseData['data'] = [];
        if (!$this->canAddToResult()) {
            return $responseData;
        }
        $queryText 	= $this->queryFactory->get()->getQueryText();
        $productResultFields = $this->helperData->getProductResultFieldsAsArray();
        $productResultFields[] = ProductFields::URL;
		$catId = count($param) ? $param['catId'] : null;
        $productCollection = $this->getProductCollection($queryText,$catId);
        foreach ($productCollection as $product) {
            $responseData['data'][] = array_intersect_key($this->getProductData($product), array_flip($productResultFields));
        }
        $responseData['size'] = $productCollection->getSize();
        $responseData['url'] = ($productCollection->getSize() > 0) ? $this->searchHelper->getResultUrl($queryText) : '';
        $responseData['catId'] = $catId;
        return $responseData;
    }
    /**
     * Retrive product collection by query text
     *
     * @param  string $queryText
     * @return mixed
     */
    protected function getProductCollection($queryText,$catId)
    {
        $productResultNumber = $this->helperData->getProductResultNumber();
        $this->layerResolver->create(LayerResolver::CATALOG_LAYER_SEARCH);
        /* $productCollection = $this->layerResolver->get()
            ->getProductCollection()
            ->addAttributeToSelect([ProductFields::DESCRIPTION, ProductFields::SHORT_DESCRIPTION])
            ->addSearchFilter($queryText);
		$productCollection->addAttributeToFilter('is_saleable', 1, 'left')
			->addAttributeToFilter('status', 1)
			->addAttributeToFilter('visibility', 4); */
			
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		if($catId > 0){
			$categoryProducts  = $objectManager->create('Magento\Catalog\Model\CategoryFactory')->create();
			$categoryProducts->load($catId);
			$productCollection = $categoryProducts->getProductCollection();
		}else{
			$productCollection = $objectManager->create('Magento\Catalog\Model\ResourceModel\Product\Collection');	
		}
		$productCollection->addAttributeToSelect('*');
		$productCollection->addAttributeToFilter('status', 1);
		$productCollection->addAttributeToFilter('visibility', 4);		
		$productCollection->addAttributeToFilter('is_saleable', 1, 'left');
		// add sort filter for collection
		$productCollection->addAttributeToSort($this->helperData->getSortFields(),$this->helperData->getSortOrder());
		// add attribute to filter
		if($this->helperData->getIsEnableAttribute()){
			$attributes = array();
			$searchAttributes = $this->helperData->getAttributeList();
			if (!empty($searchAttributes)) {
				$attributes = explode(',', $searchAttributes);
			}
			$listAttr[] = array('attribute'=>'name', 'like'=> ['%' . $queryText . '%']);
			foreach($attributes as $_attribute){
				$productCollection->addAttributeToSelect($_attribute);
				$listAttr[]	= array('attribute'=>$_attribute, 'like'=> ['%' . $queryText . '%']);
			}
			$productCollection->addAttributeToFilter($listAttr,null,'left');
			if(!$productCollection->count()){
				$productCollection->clear()->getSelect()->reset('where');
				$arrQueryText = explode(' ', $queryText);
				foreach($arrQueryText as $text){
					$productCollection->addAttributeToFilter('name', array('like'=> ['%' . trim($text) . '%']));
				}
			}
		}else{
			$arrQueryText = explode(' ', $queryText);
			foreach($arrQueryText as $text){
				$productCollection->addAttributeToFilter('name', array('like'=> ['%' . trim($text) . '%']));
			}
		}
        $productCollection->getSelect()->limit($productResultNumber);
        return $productCollection;
    }
    /**
     * Retrieve all product data
     *
     * @param \Magento\Catalog\Model\Product $product
     * @return array
     */
    protected function getProductData($product)
    {
        /** @var \V2Agency\Ajaxsearch\Block\Autocomplete\Product $product */
        $product = $this->objectManager->create('V2Agency\Ajaxsearch\Block\Autocomplete\ProductAgregator')
            ->setProduct($product);
        $data = [
            ProductFields::NAME => $product->getName(),
            ProductFields::SKU => $product->getSku(),
            ProductFields::IMAGE => $product->getSmallImage(),
            ProductFields::REVIEWS_RATING => $product->getReviewsRating(),
            ProductFields::SHORT_DESCRIPTION => $product->getShortDescription(),
            ProductFields::DESCRIPTION => $product->getDescription(),
            ProductFields::PRICE => $product->getPrice(),
            ProductFields::ADD_TO_CART => $product->getAddToCartData(),
            ProductFields::URL => $product->getUrl()
        ];
        return $data;
    }
    /**
     * {@inheritdoc}
     */
    public function canAddToResult()
    {
        return in_array(AutocompleteFields::PRODUCT, $this->helperData->getAutocompleteFieldsAsArray());
    }
}