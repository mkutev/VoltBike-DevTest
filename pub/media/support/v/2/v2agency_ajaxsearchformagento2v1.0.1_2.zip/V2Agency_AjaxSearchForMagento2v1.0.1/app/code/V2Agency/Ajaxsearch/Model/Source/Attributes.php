<?php
/**
 * Copyright © 2019 V2Agency . All rights reserved.
 * 
 */
namespace V2Agency\Ajaxsearch\Model\Source;
class Attributes
{
    /**
     *
     * @return array
     */
    public function toOptionArray()
    {
		foreach ($this->getAttributes() as $_attribute){
			$this->options[] = ['value' => $_attribute["attribute_code"], 'label' => $_attribute["frontend_label"]];
		}
        return $this->options;
    }
	public function getAttributes()
	{
		/* \Magento\Eav\Api\AttributeRepositoryInterface $eavAttributeRepository
		$attributes = $this->eavAttributeRepository->get(\Magento\Catalog\Api\Data\ProductAttributeInterface::ENTITY_TYPE_CODE,$attributeCode);
        $options = $attributes->getSource()->getAllOptions(false); */
		
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$attrs = $objectManager->get('\Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory')->create();
		$attrs->setOrder('attribute_id','ASC');
		$attrs->getItems();
		return $attrs;
	}
}