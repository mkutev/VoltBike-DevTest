<?php
/**
 * Copyright © 2019 V2Agency . All rights reserved.
 * 
 */
namespace V2Agency\Ajaxsearch\Helper;
use Magento\Store\Model\ScopeInterface;
/**
 * Search Suite Autocomplete config data helper
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * XML config path
     */
    const XML_PATH_SEARCH_CATEGORIES      		= 'v2agency_ajaxsearch/ajaxsearch_main/search_categories';
    const XML_PATH_SEARCH_DELAY      			= 'v2agency_ajaxsearch/ajaxsearch_main/search_delay';
    const XML_PATH_AUTOCOMPLETE_FIELDS      	= 'v2agency_ajaxsearch/ajaxsearch_main/autocomplete_fields';
    const XML_PATH_SUGGESTED_RESULT_NUMBER      = 'v2agency_ajaxsearch/ajaxsearch_main/suggested_result_number';
    const XML_PATH_PRODUCT_RESULT_NUMBER      	= 'v2agency_ajaxsearch/ajaxsearch_main/product_result_number';
    const XML_PATH_PRODUCT_RESULT_FIELDS      	= 'v2agency_ajaxsearch/ajaxsearch_main/product_result_fields';
    const XML_PATH_PAGE_RESULT_FIELDS      		= 'v2agency_ajaxsearch/ajaxsearch_main/page_result_number';
    const XML_PATH_CATEGORIES_RESULT_FIELDS     = 'v2agency_ajaxsearch/ajaxsearch_main/categories_result_number';
    const XML_PATH_ATTRIBUTE_ENABLE			    = 'v2agency_ajaxsearch/ajaxsearch_main/attribute_enable';
    const XML_PATH_ATTRIBUTE_LIST			    = 'v2agency_ajaxsearch/ajaxsearch_main/product_attribute';
    const XML_PATH_NUMBER_SHORTDES			    = 'v2agency_ajaxsearch/ajaxsearch_main/number_shortdes';
    const XML_PATH_MODULE_AVAIABLE		      	= 'v2agency_ajaxsearch/general/enable';
    const XML_PATH_ICON_LOADDING		      	= 'v2agency_ajaxsearch/general/load_icon';
    const XML_PATH_SORT_FIELDS      			= 'v2agency_ajaxsearch/general/sort_fields';
    const XML_PATH_SORT_ORDER	      			= 'v2agency_ajaxsearch/general/sort_order';
    const XML_PATH_PLACEHOLDER_TEXT		      	= 'v2agency_ajaxsearch/general/text_box';
    const XML_PATH_DISPLAY_HEADER			    = 'v2agency_ajaxsearch/general/result_header';
    const XML_PATH_HEADER_TITLE				    = 'v2agency_ajaxsearch/general/header_title';
    const XML_PATH_DISPLAY_FOOTER			    = 'v2agency_ajaxsearch/general/result_footer';
    const XML_PATH_FOOTER_TITLE				    = 'v2agency_ajaxsearch/general/footer_title';
    const XML_PATH_MICRO_ON_ICON                = 'v2agency_ajaxsearch/voice_search/micicon_on';
    const XML_PATH_MICRO_OFF_ICON               = 'v2agency_ajaxsearch/voice_search/micicon_off';
    const XML_PATH_VOICE_SEARCH_ENABLE          = 'v2agency_ajaxsearch/voice_search/enable';
    public function getVoiceSearchEnable($storeId = null){
        return (int)$this->scopeConfig->getValue(
            self::XML_PATH_VOICE_SEARCH_ENABLE,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
    public function getMicroOnIcon($storeId = null){
        return $this->scopeConfig->getValue(
            self::XML_PATH_MICRO_ON_ICON,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
    public function getMicroOffIcon($storeId = null){
        return $this->scopeConfig->getValue(
            self::XML_PATH_MICRO_OFF_ICON,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
	public function getModuleAvaiable($storeId = null)
    {
        return (int)$this->scopeConfig->getValue(
            self::XML_PATH_MODULE_AVAIABLE,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
	public function getLoadingIcon($storeId = null)
    {
        return (int)$this->scopeConfig->getValue(
            self::XML_PATH_ICON_LOADDING,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
    /**
     * Retrieve search categories
     *
     * @param int|null $storeId
     * @return boolean
     */
    public function getSearchCategories($storeId = null)
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_SEARCH_CATEGORIES,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
    /**
     * Retrieve sort fields
     *
     * @param int|null $storeId
     * @return string
     */
    public function getSortFields($storeId = null)
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_SORT_FIELDS,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
    /**
     * Retrieve sort order
     *
     * @param int|null $storeId
     * @return string
     */
    public function getSortOrder($storeId = null)
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_SORT_ORDER,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
    /**
     * Retrieve search delay
     *
     * @param int|null $storeId
     * @return int
     */
    public function getSearchDelay($storeId = null)
    {
        return (int)$this->scopeConfig->getValue(
            self::XML_PATH_SEARCH_DELAY,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
    /**
     * Retrieve comma-separated autocomplete fields
     *
     * @param int|null $storeId
     * @return string
     */
    public function getAutocompleteFields($storeId = null)
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_AUTOCOMPLETE_FIELDS,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
    /**
     * Retrieve list of autocomplete fields
     *
     * @param int|null $storeId
     * @return array
     */
    public function getAutocompleteFieldsAsArray($storeId = null)
    {
        return explode(',', $this->getAutocompleteFields($storeId));
    }
    /**
     * Retrieve suggest results number
     *
     * @param int|null $storeId
     * @return int
     */
    public function getSuggestedResultNumber($storeId = null)
    {
        return (int)$this->scopeConfig->getValue(
            self::XML_PATH_SUGGESTED_RESULT_NUMBER,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
    public function getProductResultNumber($storeId = null)
    {
        return (int)$this->scopeConfig->getValue(
            self::XML_PATH_PRODUCT_RESULT_NUMBER,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
    public function getPageResultNumber($storeId = null)
    {
        return (int)$this->scopeConfig->getValue(
            self::XML_PATH_PAGE_RESULT_FIELDS,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
    public function getCategoriesResultNumber($storeId = null)
    {
        return (int)$this->scopeConfig->getValue(
            self::XML_PATH_CATEGORIES_RESULT_FIELDS,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
    public function getIsEnableAttribute($storeId = null)
    {
        return (int)$this->scopeConfig->getValue(
            self::XML_PATH_ATTRIBUTE_ENABLE,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
    public function getNumberShortDes($storeId = null)
    {
        return (int)$this->scopeConfig->getValue(
            self::XML_PATH_NUMBER_SHORTDES,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
    public function getAttributeList($storeId = null)
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_ATTRIBUTE_LIST,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
    public function getIsDisplayHeader($storeId = null)
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_DISPLAY_HEADER,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
    public function getHeaderText($storeId = null)
    {
		return $this->getIsDisplayHeader() ? $this->scopeConfig->getValue(
			self::XML_PATH_HEADER_TITLE,
			ScopeInterface::SCOPE_STORE,
			$storeId
		) : null;
    }
    public function getIsDisplayFooter($storeId = null)
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_DISPLAY_FOOTER,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
	public function getFooterText($storeId = null)
    {
		return $this->getIsDisplayFooter() ? $this->scopeConfig->getValue(
			self::XML_PATH_FOOTER_TITLE,
			ScopeInterface::SCOPE_STORE,
			$storeId
		) : null;
    }
    /**
     * Retrieve comma-separated product result fields
     *
     * @param int|null $storeId
     * @return string
     */
    public function getProductResultFields($storeId = null)
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_PRODUCT_RESULT_FIELDS,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
    public function getPlaceHolderText($storeId = null)
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_PLACEHOLDER_TEXT,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
    /**
     * Retrieve list of product result fields
     *
     * @param int|null $storeId
     * @return array
     */
    public function getProductResultFieldsAsArray($storeId = null)
    {
        return explode(',', $this->getProductResultFields($storeId));
    }
	public function getUrlBilder($path = ''){
		 return $this->_urlBuilder->getUrl($path);
	}
	public function getCategoriesList(){
		$categories = array();
		
		return $categories;
	}
}