<?php
/**
* Copyright © 2019 V2Agency . All rights reserved.
*
*/
namespace V2Agency\Sociallogin\Block\Form;

class Create extends \Magento\Customer\Block\Form\Register
{
    protected function _prepareLayout()
    {
       return parent::_prepareLayout();
    }
}
?>