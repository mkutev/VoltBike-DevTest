<?php
namespace V2Agency\Sociallogin\Block\Linkedin;

class Button extends \Magento\Framework\View\Element\Template {

	protected $_clientModel;
    protected $_customerSession;
    protected $_helper;

    public function __construct(
		\Magento\Catalog\Block\Product\Context $context,
		array $data = [],
		\V2Agency\Sociallogin\Model\Linkedin\Client $clientModel,
		\Magento\Customer\Model\Session $customerSession,
		\V2Agency\Sociallogin\Helper\Data $helper
	) {
		parent::__construct($context, $data);
		$this->_clientModel			= $clientModel;
		$this->_customerSession 	= $customerSession;
		$this->_helper 				= $helper;

		if(!($this->_helper->getModuleEnable())){
            return;
        }

        if(!($this->_clientModel->isEnabled())) {
            return;
        }

        $this->setTemplate('V2Agency_Sociallogin::linkedin/button.phtml');
    }

    public function _getButtonUrl()
    {
        return $this->_clientModel->createAuthUrl();
    }

    public function _getButtonText()
    {
        $text = $this->__('Connect');
        return $text;
    }

    public function _getButtonClass()
    {
        $text = "mh_linkedin_connect mh_social_connect";
        return $text;
    }
}