<?php
/**
* Copyright © 2019 V2Agency . All rights reserved.
*
*/
namespace V2Agency\Sociallogin\Block\Form;

class Forgot extends \Magento\Customer\Block\Account\Forgotpassword
{
    protected function _prepareLayout()
    {
       return parent::_prepareLayout();
    }
}
?>