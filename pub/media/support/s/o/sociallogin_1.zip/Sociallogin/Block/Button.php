<?php
namespace V2Agency\Sociallogin\Block;

class Button extends \Magento\Framework\View\Element\Template {

    protected $_customerSession;
    protected $_helper;

     public function __construct(
		\Magento\Catalog\Block\Product\Context $context,
		array $data = [],
		\Magento\Customer\Model\Session $customerSession,
		\V2Agency\Sociallogin\Helper\Data $helper
	) {
        parent::__construct($context, $data);
		$this->_customerSession 	= $customerSession;
		$this->_helper 				= $helper;
        if($this->_customerSession->isLoggedIn()){
            return;
        }
		if(!($this->_helper->getModuleEnable())){
            return;
        }
    }

	 /**
     * @return AbstractBlock
     */
    protected function _prepareLayout()
    {
		$this->addChild('social.login.facebook','V2Agency\Sociallogin\Block\Facebook\Button');
		$this->addChild('social.login.google','V2Agency\Sociallogin\Block\Google\Button');
		$this->addChild('social.login.twitter','V2Agency\Sociallogin\Block\Twitter\Button');
		$this->addChild('social.login.instagram','V2Agency\Sociallogin\Block\Instagram\Button');
		$this->addChild('social.login.linkedin','V2Agency\Sociallogin\Block\Linkedin\Button');
		$this->addChild('social.login.youtube','V2Agency\Sociallogin\Block\Youtube\Button');
		$this->addChild('social.login.amazon','V2Agency\Sociallogin\Block\Amazon\Button');
        /* $this->setTemplate('V2Agency_Sociallogin::button.phtml'); */
        return parent::_prepareLayout();
    }

	public function getListItems(){
		$blocks = array(
			'social.login.facebook' => $this->_helper->getFacebookOrder(),
			'social.login.google' => $this->_helper->getGoogleOrder(),
			'social.login.twitter' => $this->_helper->getTwitterOrder(),
			'social.login.instagram' => $this->_helper->getInstagramOrder(),
			'social.login.linkedin' => $this->_helper->getLinkedinOrder(),
			'social.login.youtube' => $this->_helper->getYoutubeOrder(),
			'social.login.amazon' => $this->_helper->getAmazonOrder()
		);
		asort($blocks);
		return $blocks;
	}
}
