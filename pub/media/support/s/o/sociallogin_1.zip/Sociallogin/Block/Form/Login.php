<?php
/**
* Copyright © 2019 V2Agency . All rights reserved.
*
*/
namespace V2Agency\Sociallogin\Block\Form;

class Login extends \Magento\Customer\Block\Form\Login
{
    protected function _prepareLayout()
    {
       return parent::_prepareLayout();
    }
}
?>