<?php
/**
* Copyright © 2019 V2Agency . All rights reserved.
*
*/
namespace V2Agency\Sociallogin\Controller\Instagram;
class Connect extends \Magento\Framework\App\Action\Action
{
    protected $referer = null;
    protected $_scopeConfig;
    protected $_resultPageFactory;
    protected $_helper;
    protected $_instagramHelper;
    protected $_json;
    protected $_coreRegistry;
    protected $_storeManager;
    protected $_customerSession;
    protected $_clientModel;
    protected $_resultRawFactory;
	public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Controller\Result\RawFactory $rawResultFactory,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
		\V2Agency\Sociallogin\Helper\Data $helper,
		\V2Agency\Sociallogin\Helper\Instagram $instagramHelper,
		\Magento\Framework\Controller\Result\JsonFactory $json,
		\Magento\Framework\Registry $coreRegistry,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Magento\Customer\Model\Session $customerSession,
		\V2Agency\Sociallogin\Model\Instagram\Client $clientModel
    )
    {
        parent::__construct($context);
		$this->_scopeConfig 		 	= $scopeConfig;
        $this->_resultPageFactory 	 	= $resultPageFactory;
        $this->_resultRawFactory        = $rawResultFactory;
		$this->_helper 				 	= $helper;
		$this->_instagramHelper 		= $instagramHelper;
        $this->_json 	 			  	= $json;
		$this->_coreRegistry 			= $coreRegistry;
		$this->_storeManager			= $storeManager;
		$this->_customerSession			= $customerSession;
		$this->_clientModel				= $clientModel;
	}

    public function execute()
    {
		//$resultRedirect = $this->resultRedirectFactory->create();
        $resultRaw = $this->_resultRawFactory->create();
		$customer = $this->_customerSession->getCustomer();
		try {
            $this->_connectCallback();
        }
        catch (Exception $e) {
           $this->messageManager->addError($e->getMessage());
        }
        if(!empty($this->referer)) {
             $output = '<script type="text/javascript">newwindow=null;window.opener.location.href = \''.$this->referer.'\' ;window.close();</script>';
             return $resultRaw->setContents($output);
        } else {
             $output = '<script type="text/javascript">newwindow=null;window.opener.location.reload();window.close();</script>';
             return $resultRaw->setContents($output);

        }
    }

	/**
     * connect to instagram account
     */
    protected function _connectCallback() {
        $code   = $this->getRequest()->getParam('code');
        if ($code) {
			$this->referer = $this->_helper->getRedirectPageAfterAuth();
            $data                   = $this->_clientModel->getOAuthToken($code);
            /* $token                  = $data->access_token; */
            $name                   = $data->user->username;
            $arrName                = explode(' ', $data->user->full_name);
			$firstName 				= $arrName[0];
			$lastName 				= isset($arrName[1]) ? $arrName[1] : $firstName;
            $email                  = $name . '@instagram.com';
            $this->_customerSession->setDataUsername($name);
            $this->_customerSession->setDataBio($data->user->bio);
            $this->_customerSession->setDataWebsite($data->user->website);
            $this->_customerSession->setDataProfilePicture($data->user->profile_picture);
            $this->_customerSession->setDataFullName($data->user->full_name);
            $customersByInstagramId = $this->_instagramHelper->getCustomersByInstagramId($data->user->id);
            if ($this->_customerSession->isLoggedIn()) {
                // Logged in user
                if ($customersByInstagramId->count()) {
                    // Instagram account already connected to other account - deny
                    $this->messageManager->addNotice(__('Your Instagram account is already connected to one of our store accounts.'));
                    return;
                }
                // Connect from account dashboard - attach
                $this->_instagramHelper->connectByInstagramId($this->_customerSession->getCustomer(), $data->user->id);
                $this->messageManager->addSuccess(__('Your Instagram account is now connected to your new user accout at our store. You can login next time by the Instagram SocialLogin button or Store user account. Account confirmation mail has been sent to your email.'));
                return;
            }
            if ($customersByInstagramId->count()) {
                // Existing connected user - login
                $customer = $customersByInstagramId->getFirstItem();
                $this->_instagramHelper->loginByCustomer($customer);
                $this->messageManager->addSuccess(__('You have successfully logged in using your Instagram account.'));
                return;
            }
            $customersByEmail = $this->_instagramHelper->getCustomersByEmail($email);
            if ($customersByEmail->count()) {
                // Email account already exists - attach, login
                $customer = $customersByEmail->getFirstItem();
                $this->_instagramHelper->connectByInstagramId($customer, $data->user->id);
                $this->messageManager->addSuccess(__('We find you already have an account at our store. Your Instagram account is now connected to your store account. Account confirmation mail has been sent to your email.'));
                return;
            }
            // New connection - create, attach, login
            if (empty($data->user->username)) {
                throw new Exception(__('Sorry, could not retrieve your Instagram username. Please try again.'));
            }
            $this->_instagramHelper->connectByCreatingAccount($email, $firstName, $lastName, $data->user->id);
            $this->messageManager->addSuccess(__('Your Instagram account is now connected to your new user accout at our store. You can login next time by the Instagram SocialLogin button or Store user account. Account confirmation mail has been sent to your email.'));
        }
    }
}