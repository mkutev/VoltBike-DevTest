<?php
/**
* Copyright © 2019 V2Agency . All rights reserved.
*
*/
namespace V2Agency\Sociallogin\Controller\Facebook;
class Connect extends \Magento\Framework\App\Action\Action
{
    protected $referer = null;
    protected $_scopeConfig;
    protected $_resultPageFactory;
    protected $_helper;
    protected $_facebookHelper;
    protected $_json;
    protected $_coreRegistry;
    protected $_storeManager;
    protected $_customerSession;
    protected $_clientModel;
    protected $_resultRawFactory;
	public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Controller\Result\RawFactory $rawResultFactory,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
		\V2Agency\Sociallogin\Helper\Data $helper,
		\V2Agency\Sociallogin\Helper\Facebook $facebookHelper,
		\Magento\Framework\Controller\Result\JsonFactory $json,
		\Magento\Framework\Registry $coreRegistry,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Magento\Customer\Model\Session $customerSession,
		\V2Agency\Sociallogin\Model\Facebook\Client $clientModel
    )
    {
        parent::__construct($context);
		$this->_scopeConfig 		 	= $scopeConfig;
        $this->_resultPageFactory 	 	= $resultPageFactory;
        $this->_resultRawFactory        = $rawResultFactory;
		$this->_helper 				 	= $helper;
		$this->_facebookHelper 			= $facebookHelper;
        $this->_json 	 			  	= $json;
		$this->_coreRegistry 			= $coreRegistry;
		$this->_storeManager			= $storeManager;
		$this->_customerSession			= $customerSession;
		$this->_clientModel				= $clientModel;
	}

    public function execute()
    {
		//$resultRedirect = $this->resultRedirectFactory->create();
        $resultRaw = $this->_resultRawFactory->create();
		$customer = $this->_customerSession->getCustomer();
        try {
            $this->_connectCallback();
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }
        if(!empty($this->referer)) {
             $output = '<script type="text/javascript">newwindow=null;window.opener.location.href = \''.$this->referer.'\' ;window.close();</script>';
             return $resultRaw->setContents($output);
        } else {
             $output = '<script type="text/javascript">newwindow=null;window.opener.location.reload();window.close();</script>';
             return $resultRaw->setContents($output);

        }
    }

	/**
     * connect to facebook account
     */
    protected function _connectCallback() {
        $errorCode = $this->getRequest()->getParam('error');

        $code = $this->getRequest()->getParam('code');

        /* $state = $this->getRequest()->getParam('state'); */
        if(!($errorCode || $code)) {
            // Direct route access - deny
            return;
        }

        $this->referer = $this->_helper->getRedirectPageAfterAuth();

        if($errorCode) {
            // Facebook API read light - abort
            if($errorCode === 'access_denied') {
                $this->messageManager->addNotice(__('Facebook Connect process aborted.'));
                return;
            }
            throw new Exception(__('Sorry, "%1" error occured. Please try again.', $errorCode));
            return;
        }

        if ($code) {

            $userInfo = $this->_clientModel->api('/me');
            $token = $this->_clientModel->getAccessToken();

            if(isset($userInfo->error)){
                $this->messageManager->addNotice($userInfo->error->message);
                return;
            }
            if(isset($userInfo->id)){
                    $customersByFacebookId = $this->_facebookHelper->getCustomersByFacebookId($userInfo->id);
                    // var_dump($userInfo->id);
                    // var_dump($customersByFacebookId->getData());

                    if($this->_customerSession->isLoggedIn()) {
                        // Logged in user
                        if($customersByFacebookId->count()) {
                            // Facebook account already connected to other account - deny
        					$this->messageManager->addNotice(__('Your Facebook account is already connected to one of our store accounts.'));
                            return;
                        }
                        // Connect from account dashboard - attach
                        $customer = $this->_customerSession->getCustomer();
                        $this->_facebookHelper->connectByFacebookId(
                            $customer,
                            $userInfo->id
                        );
                        $this->messageManager->addSuccess(__('Your Facebook account is now connected to your new user accout at our store. You can login next time by the Facebook SocialLogin button or Store user account. Account confirmation mail has been sent to your email.'));

        				return;
                    }
                    //var_dump($customersByFacebookId->count());die;
                    if($customersByFacebookId->count()) {

                        // Existing connected user - login
                        $customer = $customersByFacebookId->getFirstItem();
                        $this->_facebookHelper->loginByCustomer($customer);

                        $this->messageManager->addSuccess(__('You have successfully logged in using your Facebook account.'));

                        return;

                    }
                    if(!isset($userInfo->email)){
                        $userInfo->email = $userInfo->id.'@facebook.com';
                    }
                    $customersByEmail = $this->_facebookHelper->getCustomersByEmail($userInfo->email);
                    if($customersByEmail->count()) {
                        // Email account already exists

                        $customer = $customersByEmail->getFirstItem();

                        $this->messageManager->addNotice(
                            __('We find email already have an account at our store. Please try other email !')
                        );
                        return;

                    }
                    // New connection - create, attach, login

                    if(empty($userInfo->first_name)) {
                        throw new Exception(__('Sorry, could not retrieve your Facebook first name. Please try again.') );
                    }

                    if(empty($userInfo->last_name)) {

                        throw new Exception(__('Sorry, could not retrieve your Facebook last name. Please try again.'));

                    }

                    $this->_facebookHelper->connectByCreatingAccount(
                        $userInfo->email,
                        $userInfo->first_name,
                        $userInfo->last_name,
                        $userInfo->id

                    );
                    $customersByFacebookId = $this->_facebookHelper->getCustomersByFacebookId($userInfo->id);
                    if($customersByFacebookId->count()) {

                        // Existing connected user - login
                        $customer = $customersByFacebookId->getFirstItem();
                        $this->_facebookHelper->loginByCustomer($customer);

                        $this->messageManager->addSuccess(__('You have successfully logged in using your Facebook account.'));

                        return;

                    }
                    $this->messageManager->addSuccess(__('Your Facebook account is now connected to your new user accout at our store. You can login next time by the Facebook SocialLogin button or Store user account. Account confirmation mail has been sent to your email.'));
            }else{
                return;
            }
        }

    }
}