<?php
/**
* Copyright © 2019 V2Agency . All rights reserved.
*
*/
namespace V2Agency\Sociallogin\Controller\Instagram;
class Connect extends \Magento\Framework\App\Action\Action
{
   protected $referer = null;
    protected $_scopeConfig;
    protected $_resultPageFactory;
    protected $_helper;
    protected $_instagramHelper;
    protected $_json;
    protected $_coreRegistry;
    protected $_storeManager;
    protected $_customerSession;
    protected $_clientModel;
	public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
		\V2Agency\Sociallogin\Helper\Data $helper,
		\V2Agency\Sociallogin\Helper\Instagram $instagramHelper,
		\Magento\Framework\Controller\Result\JsonFactory $json,
		\Magento\Framework\Registry $coreRegistry,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Magento\Customer\Model\Session $customerSession,
		\V2Agency\Sociallogin\Model\Instagram\Client $clientModel
    )
    {
        parent::__construct($context);
		$this->_scopeConfig 		 	= $scopeConfig;
        $this->_resultPageFactory 	 	= $resultPageFactory;
		$this->_helper 				 	= $helper;
		$this->_instagramHelper 		= $instagramHelper;
        $this->_json 	 			  	= $json;
		$this->_coreRegistry 			= $coreRegistry;
		$this->_storeManager			= $storeManager;
		$this->_customerSession			= $customerSession;
		$this->_clientModel				= $clientModel;
	}

	public function execute()
	{

		$customer = $this->_customerSession->getCustomer();
        try {
            $this->_disconnectCallback($customer);
        }
        catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }
        if(!empty($this->referer)) {
            return $resultRedirect->setPath($this->referer);
        } else {
            return $resultRedirect->setPath('no-router');
        }
    }

	protected function _disconnectCallback(\Magento\Customer\Model\Customer $customer)
    {
        $this->referer = $this->_helper->getUrlBilder('v2agencysociallogin/account/instagram');
        $this->_instagramHelper->disconnect($customer);
        $this->messageManager->addSuccess(__('You have successfully disconnected your instagram account from our store account.'));
    }
}