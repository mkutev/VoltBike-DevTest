<?php
/**
* Copyright © 2019 V2Agency . All rights reserved.
*
*/
namespace V2Agency\Sociallogin\Controller\Facebook;
class Disconect extends \Magento\Framework\App\Action\Action
{
    protected $referer = null;
	protected $_scopeConfig;
    protected $_resultPageFactory;
    protected $_helper;
    protected $_facebookHelper;
    protected $_json;
    protected $_coreRegistry;
    protected $_storeManager;
	protected $_customerSession;
    protected $_clientModel;
	public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
		\V2Agency\Sociallogin\Helper\Facebook $facebookHelper,
		\Magento\Framework\Controller\Result\JsonFactory $json,
		\Magento\Framework\Registry $coreRegistry,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Magento\Customer\Model\Session $customerSession,
		\V2Agency\Sociallogin\Model\Facebook\Client $clientModel
    )
    {
		$this->_scopeConfig 		 	= $scopeConfig;
        $this->_resultPageFactory 	 	= $resultPageFactory;
		$this->_facebookHelper 			= $facebookHelper;
        $this->_json 	 			  	= $json;
		$this->_coreRegistry 			= $coreRegistry;
		$this->_storeManager			= $storeManager;
		$this->_customerSession			= $customerSession;
		$this->_clientModel				= $clientModel;
        parent::__construct($context);
	}

	public function execute()
	{
		$resultRedirect = $this->resultRedirectFactory->create();
        $customer = $this->_customerSession->getCustomer();
        try {
            $this->_disconnectCallback($customer);
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }

        if(!empty($this->referer)) {
            return $resultRedirect->setPath($this->referer);
        } else {
            return $resultRedirect->setPath('no-router');
        }
    }

	/**
     * disconnect from facebook account
     */
    protected function _disconnectCallback(\Magento\Customer\Model\Customer $customer) {
        $this->referer = $this->_helper->getUrlBilder('v2agencysociallogin/account/facebook');
        $this->_helper->disconnect($customer);
        $this->messageManager->addSuccess(__('You have successfully disconnected your Facebook account from our store account.'));
    }
}