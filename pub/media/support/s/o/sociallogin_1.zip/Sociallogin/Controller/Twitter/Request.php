<?php
/**
* Copyright © 2019 V2Agency . All rights reserved.
*
*/
namespace V2Agency\Sociallogin\Controller\Twitter;
class Request extends \Magento\Framework\App\Action\Action
{
	protected $referer = null;
	protected $_scopeConfig;
    protected $_resultPageFactory;
    protected $_helper;
    protected $_helperTwitter;
    protected $_facebookHelper;
    protected $_json;
    protected $_coreRegistry;
    protected $_storeManager;
	protected $_customerSession;
    protected $_clientModel;
	public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
		\V2Agency\Sociallogin\Helper\Data $helper,
		\V2Agency\Sociallogin\Helper\Twitter $helperTwitter,
		\Magento\Framework\Controller\Result\JsonFactory $json,
		\Magento\Framework\Registry $coreRegistry,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Magento\Customer\Model\Session $customerSession,
		\V2Agency\Sociallogin\Model\Twitter\Client $clientModel
    )
    {
		$this->_scopeConfig 		 	= $scopeConfig;
        $this->_resultPageFactory 	 	= $resultPageFactory;
		$this->_helper 				 	= $helper;
		$this->_helperTwitter 			= $helperTwitter;
        $this->_json 	 			  	= $json;
		$this->_coreRegistry 			= $coreRegistry;
		$this->_storeManager			= $storeManager;
		$this->_customerSession			= $customerSession;
		$this->_clientModel				= $clientModel;
        parent::__construct($context);
	}

    public function execute()
    {
        if(!($this->_clientModel->isEnabled())) {
           return $resultRedirect->setPath('no-router');
        }

        $this->_clientModel->fetchRequestToken();
    }
}
