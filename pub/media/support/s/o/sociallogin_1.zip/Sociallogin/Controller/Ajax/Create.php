<?php
/**
* Copyright © 2019 V2Agency . All rights reserved.
*
*/
namespace V2Agency\Sociallogin\Controller\Ajax;

use Magento\Customer\Api\AccountManagementInterface;
use Magento\Customer\Api\Data\AddressInterfaceFactory;
use Magento\Customer\Api\Data\CustomerInterfaceFactory;
use Magento\Customer\Api\Data\RegionInterfaceFactory;
use Magento\Customer\Controller\Account\CreatePost;
use Magento\Customer\Helper\Address;
use Magento\Customer\Model\Account\Redirect as AccountRedirect;
use Magento\Customer\Model\CustomerExtractor;
use Magento\Customer\Model\Metadata\FormFactory;
use Magento\Customer\Model\Registration;
use Magento\Customer\Model\Session;
use Magento\Customer\Model\Url as CustomerUrl;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Escaper;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\StateException;
use Magento\Framework\Stdlib\Cookie\CookieMetadataFactory;
use Magento\Framework\Stdlib\Cookie\PhpCookieManager;
use Magento\Framework\UrlFactory;
use Magento\Newsletter\Model\SubscriberFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Captcha\Helper\Data;
use Magento\Captcha\Observer\CaptchaStringResolver;
class Create extends CreatePost
{

    protected $_Json;

    private $cookieMetadataManager;

    private $cookieMetadataFactory;

    private $_helperCaptcha;

    protected $captchaStringResolver;

    public function __construct(
        Context $context,
        Session $customerSession,
        ScopeConfigInterface $scopeConfig,
        StoreManagerInterface $storeManager,
        AccountManagementInterface $accountManagement,
        Address $addressHelper,
        UrlFactory $urlFactory,
        FormFactory $formFactory,
        SubscriberFactory $subscriberFactory,
        RegionInterfaceFactory $regionDataFactory,
        AddressInterfaceFactory $addressDataFactory,
        CustomerInterfaceFactory $customerDataFactory,
        CustomerUrl $customerUrl,
        Registration $registration,
        Escaper $escaper,
        CustomerExtractor $customerExtractor,
        DataObjectHelper $dataObjectHelper,
        AccountRedirect $accountRedirect,
        JsonFactory $resultJsonFactory,
        Data $helperCaptcha,
        CaptchaStringResolver $captchaStringResolver
    )
    {
        $this->_Json = $resultJsonFactory;
        $this->_helperCaptcha = $helperCaptcha;
        $this->captchaStringResolver = $captchaStringResolver;
        parent::__construct(
            $context,
            $customerSession,
            $scopeConfig,
            $storeManager,
            $accountManagement,
            $addressHelper,
            $urlFactory,
            $formFactory,
            $subscriberFactory,
            $regionDataFactory,
            $addressDataFactory,
            $customerDataFactory,
            $customerUrl,
            $registration,
            $escaper,
            $customerExtractor,
            $dataObjectHelper,
            $accountRedirect
        );
    }

    protected function getCookieManager()
    {
        if (!$this->cookieMetadataManager) {
            $this->cookieMetadataManager = ObjectManager::getInstance()->get(
                PhpCookieManager::class
            );
        }
        return $this->cookieMetadataManager;
    }

    protected function getCookieMetadataFactory()
    {
        if (!$this->cookieMetadataFactory) {
            $this->cookieMetadataFactory = ObjectManager::getInstance()->get(
                CookieMetadataFactory::class
            );
        }
        return $this->cookieMetadataFactory;
    }

    public function execute()
    {
        $resultJson = $this->_Json->create();

        $response = [
            'status' => 0,
            'message' => __('Error! Please try again.')
        ];

        if ($this->session->isLoggedIn() || !$this->registration->isAllowed()) {
              $result['url'] = $this->urlModel->getUrl('customer/account');
              return $resultJson->setData($response);
        }

        if (!$this->getRequest()->isPost()) {
           return $resultJson->setData($response);
        }
        $formId = 'user_create';
        $captchaModel = $this->_helperCaptcha->getCaptcha($formId);
        if ($captchaModel->isRequired()) {

            if (!$captchaModel->isCorrect($this->captchaStringResolver->resolve($this->getRequest(), $formId))) {
                $response['message'] = __('Incorrect CAPTCHA');
                return $resultJson->setData($response);
            }
        }
        $this->session->regenerateId();

        try {
            $address = $this->extractAddress();
            $addresses = $address === null ? [] : [$address];

            $customer = $this->customerExtractor->extract('customer_account_create', $this->_request);
            $customer->setAddresses($addresses);

            $password = $this->getRequest()->getParam('password');
            $confirmation = $this->getRequest()->getParam('password_confirmation');
            $redirectUrl = $this->session->getBeforeAuthUrl();

            if(!$this->checkPasswordConfirmation($password, $confirmation)){
                 $response['message'] = __('Please make sure your passwords match!');
                 return $resultJson->setData($response);
            }

            $customer = $this->accountManagement
                ->createAccount($customer, $password, $redirectUrl);
            $response['status'] = 1;
            if ($this->getRequest()->getParam('is_subscribed', false)) {
                $this->subscriberFactory->create()->subscribeCustomerById($customer->getId());
            }

            $this->_eventManager->dispatch(
                'customer_register_success',
                ['account_controller' => $this, 'customer' => $customer]
            );

            $confirmationStatus = $this->accountManagement->getConfirmationStatus($customer->getId());
            if ($confirmationStatus === AccountManagementInterface::ACCOUNT_CONFIRMATION_REQUIRED) {
                $email = $this->customerUrl->getEmailConfirmationUrl($customer->getEmail());
                // @codingStandardsIgnoreStart
                $this->messageManager->addSuccess(
                    __(
                        'You must confirm your account. Please check your email for the confirmation link or <a href="%1">click here</a> for a new link.',
                        $email
                    )
                );
                // @codingStandardsIgnoreEnd
                //$response['url'] = $this->urlModel->getUrl('*/*/index', ['_secure' => true]);
            } else {
                $this->session->setCustomerDataAsLoggedIn($customer);
                $this->messageManager->addSuccess($this->getSuccessMessage());
                $response['message'] = $this->getSuccessMessage();


            }
            if ($this->getCookieManager()->getCookie('mage-cache-sessid')) {
                $metadata = $this->getCookieMetadataFactory()->createCookieMetadata();
                $metadata->setPath('/');
                $this->getCookieManager()->deleteCookie('mage-cache-sessid', $metadata);
            }

            return $resultJson->setData($response);
        } catch (StateException $e) {
            $url = $this->urlModel->getUrl('customer/account/forgotpassword');
            // @codingStandardsIgnoreStart
            $message = __(
                'There is already an account with this email address. If you are sure that it is your email address, <a href="%1">click here</a> to get your password and access your account.',
                $url
            );
            // @codingStandardsIgnoreEnd
            $response['message'] = $message;
        } catch (InputException $e) {
            $response['message'] = $this->escaper->escapeHtml($e->getMessage());

        } catch (LocalizedException $e) {
            $response['message'] = $this->escaper->escapeHtml($e->getMessage());
        } catch (\Exception $e) {
            $response['message'] =  __('We can\'t save the customer.');
        }

        $this->session->setCustomerFormData($this->getRequest()->getPostValue());
        //$response['url'] = $this->urlModel->getUrl('*/*/create', ['_secure' => true]);

        return $resultJson->setData($response);
    }

    protected function checkPasswordConfirmation($password, $confirmation)
    {
        return $password == $confirmation;
    }
}
