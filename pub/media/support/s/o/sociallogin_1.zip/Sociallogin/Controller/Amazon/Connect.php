<?php
/**
* Copyright © 2019 V2Agency . All rights reserved.
*
*/
namespace V2Agency\Sociallogin\Controller\Amazon;
class Connect extends \Magento\Framework\App\Action\Action
{
    protected $referer = null;
	protected $_scopeConfig;
    protected $_resultPageFactory;
    protected $_helper;
    protected $_amazonHelper;
    protected $_json;
    protected $_coreRegistry;
    protected $_storeManager;
    protected $_customerSession;
    protected $_clientModel;
    protected $_resultRawFactory;
	public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Controller\Result\RawFactory $rawResultFactory,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
		\V2Agency\Sociallogin\Helper\Data $helper,
		\V2Agency\Sociallogin\Helper\Amazon $amazonHelper,
		\Magento\Framework\Controller\Result\JsonFactory $json,
		\Magento\Framework\Registry $coreRegistry,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Magento\Customer\Model\Session $customerSession,
		\V2Agency\Sociallogin\Model\Amazon\Client $clientModel
    )
    {
        parent::__construct($context);
		$this->_scopeConfig 		 	= $scopeConfig;
        $this->_resultPageFactory 	 	= $resultPageFactory;
        $this->_resultRawFactory        = $rawResultFactory;
		$this->_helper 				 	= $helper;
		$this->_amazonHelper 			= $amazonHelper;
        $this->_json 	 			  	= $json;
		$this->_coreRegistry 			= $coreRegistry;
		$this->_storeManager			= $storeManager;
		$this->_customerSession			= $customerSession;
		$this->_clientModel				= $clientModel;
	}

	public function execute()
    {
		//$resultRedirect = $this->resultRedirectFactory->create();
        $resultRaw = $this->_resultRawFactory->create();
        try {
            $this->_connectCallback();
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }

       if(!empty($this->referer)) {
             $output = '<script type="text/javascript">newwindow=null;window.opener.location.href = \''.$this->referer.'\' ;window.close();</script>';
             return $resultRaw->setContents($output);
        } else {
             $output = '<script type="text/javascript">newwindow=null;window.opener.location.reload();window.close();</script>';
             return $resultRaw->setContents($output);

        }
    }

    protected function _connectCallback() {
        $errorCode = $this->getRequest()->getParam('error');
        $code = $this->getRequest()->getParam('code');
        $state = $this->getRequest()->getParam('state');
        if(!($errorCode || $code)) {
            // Direct route access - deny
            return;
        }

        $this->referer = $this->_helper->getRedirectPageAfterAuth();
        /* if(!$state || $state != $this->_customerSession->getAmazonCsrf()) {
            return;
        } */
		/* $this->_customerSession->getAmazonCsrf(''); */
        if($errorCode) {
            // Amazon API read light - abort
            if($errorCode === 'access_denied') {
                $this->messageManager->addNotice(__('Amazon Connect process aborted.'));
                return;
            }
            throw new Exception(__('Sorry, "%1" error occured. Please try again.',$errorCode));
            return;
        }

        if ($code) {
            // Amazon API green light - proceed
            $userInfo = $this->_clientModel->api('/account/endpoint');
			$arrName                = explode(' ', $userInfo->name);
			$firstName 				= $arrName[0];
			$lastName 				= isset($arrName[1]) ? $arrName[1] : $firstName;
            $token = $this->_clientModel->getAccessToken();
            $customersByAmazonId = $this->_amazonHelper->getCustomersByAmazonId($userInfo->user_id);

            if($this->_customerSession->isLoggedIn()) {
                // Logged in user
                if($customersByAmazonId->count()) {
                    // Amazon account already connected to other account - deny
                    $this->messageManager->addNotice(__('Your Amazon account is already connected to one of our store accounts.'));
                    return;
                }

                // Connect from account dashboard - attach
                $customer = $this->_customerSession->getCustomer();
                $this->_amazonHelper->connectByAmazonId(
                    $customer,
                    $userInfo->user_id
                );

                $this->messageManager->addSuccess(__('Your Amazon account is now connected to your new user accout at our store. You can login next time by the Amazon SocialLogin button or Store user account. Account confirmation mail has been sent to your email.'));
                return;
            }
            if($customersByAmazonId->count()) {
                // Existing connected user - login
                $customer = $customersByAmazonId->getFirstItem();
                $this->_amazonHelper->loginByCustomer($customer);
				$this->messageManager->addSuccess(__('You have successfully logged in using your Amazon account.'));
                return;
            }
            $customersByEmail = $this->_amazonHelper->getCustomersByEmail($userInfo->email);
            if($customersByEmail->count())  {
                // Email account already exists - attach, login
                $customer = $customersByEmail->getFirstItem();

                $this->_amazonHelper->connectByAmazonId(
                    $customer,
                    $userInfo->user_id
                );

                $this->messageManager->addSuccess(__('We find you already have an account at our store. Your Amazon account is now connected to your store account. Account confirmation mail has been sent to your email.'));
                return;
            }
            // New connection - create, attach, login
            if(empty($firstName)) {
                throw new Exception(__('Sorry, could not retrieve your Amazon first name. Please try again.'));
            }

            if(empty($lastName)) {
                throw new Exception(__('Sorry, could not retrieve your Amazon last name. Please try again.'));
            }
            $this->_amazonHelper->connectByCreatingAccount(
                $userInfo->email,
                $firstName,
                $lastName,
                $userInfo->user_id
            );
            $this->messageManager->addSuccess(__('Your Amazon account is now connected to your new user accout at our store. You can login next time by the Amazon SocialLogin button or Store user account. Account confirmation mail has been sent to your email.'));

		}
    }
}