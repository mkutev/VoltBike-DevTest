<?php
/**
* Copyright © 2019 V2Agency . All rights reserved.
*
*/
namespace V2Agency\Sociallogin\Controller\Youtube;
class Connect extends \Magento\Framework\App\Action\Action
{
    protected $referer = null;
	protected $_scopeConfig;
    protected $_resultPageFactory;
    protected $_helper;
    protected $_youtubeHelper;
    protected $_json;
    protected $_coreRegistry;
    protected $_storeManager;
    protected $_customerSession;
    protected $_clientModel;
    protected $_resultRawFactory;
	public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Controller\Result\RawFactory $rawResultFactory,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
		\V2Agency\Sociallogin\Helper\Data $helper,
		\V2Agency\Sociallogin\Helper\Youtube $youtubeHelper,
		\Magento\Framework\Controller\Result\JsonFactory $json,
		\Magento\Framework\Registry $coreRegistry,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Magento\Customer\Model\Session $customerSession,
		\V2Agency\Sociallogin\Model\Youtube\Client $clientModel
    )
    {
        parent::__construct($context);
		$this->_scopeConfig 		 	= $scopeConfig;
        $this->_resultPageFactory 	 	= $resultPageFactory;
        $this->_resultRawFactory        = $rawResultFactory;
		$this->_helper 				 	= $helper;
		$this->_youtubeHelper 			= $youtubeHelper;
        $this->_json 	 			  	= $json;
		$this->_coreRegistry 			= $coreRegistry;
		$this->_storeManager			= $storeManager;
		$this->_customerSession			= $customerSession;
		$this->_clientModel				= $clientModel;
	}

	public function execute()
    {
		//$resultRedirect = $this->resultRedirectFactory->create();
        $resultRaw = $this->_resultRawFactory->create();
        try {
            $this->_connectCallback();
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }

        if(!empty($this->referer)) {
             $output = '<script type="text/javascript">newwindow=null;window.opener.location.href = \''.$this->referer.'\' ;window.close();</script>';
             return $resultRaw->setContents($output);
        } else {
             $output = '<script type="text/javascript">newwindow=null;window.opener.location.reload();window.close();</script>';
             return $resultRaw->setContents($output);

        }
    }

    protected function _connectCallback() {
        $errorCode = $this->getRequest()->getParam('error');
        $code = $this->getRequest()->getParam('code');
        /* $state = $this->getRequest()->getParam('state'); */
        if(!($errorCode || $code)) {
            // Direct route access - deny
            return;
        }
        $this->referer = $this->_helper->getRedirectPageAfterAuth();
        /* if(!$state || $state != $this->_customerSession->getGoogleCsrf()) {
            return;
        } */
		/* $this->_customerSession->getGoogleCsrf(''); */
        if($errorCode) {
            // Google API read light - abort
            if($errorCode === 'access_denied') {
                $this->messageManager->addNotice(__('Youtube connect process aborted.'));
                return;
            }
            throw new Exception(__('Sorry, "%1" error occured. Please try again.',$errorCode));
            return;
        }

        if ($code) {
            // Youtube API green light - proceed
            $userInfo = $this->_clientModel->api('channels');
			$id 	= $userInfo->items[0]->id;
            $name = ' ';
            if($userInfo->items[0]->brandingSettings){
                $name   = $userInfo->items[0]->brandingSettings->channel->title;
            }else{
                $this->messageManager->addNotice__('Sorry, could not retrieve your Youtube name. Please try again.'));
                    return;
            }

			$arrName                = explode(' ', $name);
			$firstName 				= $arrName[0];
			$lastName 				= isset($arrName[1]) ? $arrName[1] : $firstName;
            $name               	= str_replace(' ', '', $name);
			$email 					= strtolower($name) . '@youtube.com';
            $token = $this->_clientModel->getAccessToken();
            $customersByYoutubeId = $this->_youtubeHelper->getCustomersByYoutubeId($id);
            if($this->_customerSession->isLoggedIn()) {
                // Logged in user
                if($customersByYoutubeId->count()) {
                    // Youtube account already connected to other account - deny
                    $this->messageManager->addNotice(__('Your Youtube account is already connected to one of our store accounts.'));
                    return;
                }

                // Connect from account dashboard - attach
                $customer = $this->_customerSession->getCustomer();
                $this->_youtubeHelper->connectByYoutubeId(
                    $customer,
                    $id
                );

                $this->messageManager->addSuccess(__('Your Youtube account is now connected to your new user accout at our store. You can login next time by the Youtube SocialLogin button or Store user account. Account confirmation mail has been sent to your email.'));
                return;
            }
            if($customersByYoutubeId->count()) {
                // Existing connected user - login
                $customer = $customersByYoutubeId->getFirstItem();
                $this->_youtubeHelper->loginByCustomer($customer);
				$this->messageManager->addSuccess(__('You have successfully logged in using your Youtube account.'));
                return;
            }
            $customersByEmail = $this->_youtubeHelper->getCustomersByEmail($email);
            if($customersByEmail->count())  {
                $this->messageManager->addNotice(
                    __('We find email already have an account at our store. Please try other email !')
                );
				return;
            }
            // New connection - create, attach, login
            if(empty($firstName)) {
                throw new Exception(__('Sorry, could not retrieve your Youtube first name. Please try again.'));
            }

            if(empty($lastName)) {
                throw new Exception(__('Sorry, could not retrieve your Youtube last name. Please try again.'));
            }
            $this->_youtubeHelper->connectByCreatingAccount(
                $email,
                $firstName,
                $lastName,
                $id
            );
            $customersByYoutubeId = $this->_youtubeHelper->getCustomersByYoutubeId($id);
            if($customersByYoutubeId->count()) {
                // Existing connected user - login
                $customer = $customersByYoutubeId->getFirstItem();
                $this->_youtubeHelper->loginByCustomer($customer);
                $this->messageManager->addSuccess(__('You have successfully logged in using your Youtube account.'));
                return;
            }
            $this->messageManager->addSuccess(__('Your Youtube account is now connected to your new user accout at our store. You can login next time by the Youtube SocialLogin button or Store user account. Account confirmation mail has been sent to your email.'));

		}
    }
}