<?php
/**
* Copyright © 2019 V2Agency . All rights reserved.
*
*/
namespace V2Agency\Sociallogin\Controller\Adminhtml;

abstract class Sociallogin extends \V2Agency\Sociallogin\Controller\Adminhtml\AbstractAction
{
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('V2Agency_Sociallogin::sociallogin');
    }
}