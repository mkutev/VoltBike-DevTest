<?php
/**
* Copyright © 2019 V2Agency . All rights reserved.
*
*/
namespace V2Agency\Sociallogin\Controller\Ajax;

use Magento\Customer\Controller\Account\ForgotPasswordPost;
use Magento\Customer\Api\AccountManagementInterface;
use Magento\Customer\Model\AccountManagement;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Escaper;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\SecurityViolationException;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Captcha\Helper\Data;
use Magento\Captcha\Observer\CaptchaStringResolver;

class Forgotpass extends \Magento\Framework\App\Action\Action
{
    protected $customerAccountManagement;

    protected $escaper;

    protected $session;

	protected $_Json;

    private $_helperCaptcha;

    protected $captchaStringResolver;

    public function __construct(
        Context $context,
        Session $customerSession,
        AccountManagementInterface $customerAccountManagement,
        Escaper $escaper,
        JsonFactory $resultJsonFactory,
        Data $helperCaptcha,
        CaptchaStringResolver $captchaStringResolver
    ) {
        $this->_Json = $resultJsonFactory;
        $this->_helperCaptcha = $helperCaptcha;
        $this->captchaStringResolver = $captchaStringResolver;
        $this->session = $customerSession;
        $this->customerAccountManagement = $customerAccountManagement;
        $this->escaper = $escaper;
        parent::__construct($context);
    }


    public function execute()
    {
        $resultJson = $this->_Json->create();
        $response = [
            'status' => 0,
            'message' => __('Error! Please try again.')
        ];
        $email = (string)$this->getRequest()->getPost('email');
        if ($email) {
        	$formId = 'user_forgotpassword';
	        $captchaModel = $this->_helperCaptcha->getCaptcha($formId);
	        if ($captchaModel->isRequired()) {

	            if (!$captchaModel->isCorrect($this->captchaStringResolver->resolve($this->getRequest(), $formId))) {
	                $response['message'] = __('Incorrect CAPTCHA');
	                return $resultJson->setData($response);
	            }
	        }


            if (!\Zend_Validate::is($email, \Magento\Framework\Validator\EmailAddress::class)) {
                $this->session->setForgottenEmail($email);

                $response['message'] = __('Please correct the email address.');
	            return $resultJson->setData($response);
            }

            try {
                $this->customerAccountManagement->initiatePasswordReset(
                    $email,
                    AccountManagement::EMAIL_RESET
                );

            } catch (NoSuchEntityException $exception) {
                // Do nothing, we don't want anyone to use this action to determine which email accounts are registered.
            } catch (SecurityViolationException $exception) {
                $response['message'] = $exception->getMessage();

            } catch (\Exception $exception) {
                $response['message'] =  __('We\'re unable to send the password reset email.');

            }
            $response = [
		            'status' => 1,
		            'message' => $this->getSuccessMessage($email)
		    ];
	        return $resultJson->setData($response);

        }
        $response['message'] =__('Please enter your email.');
        return $resultJson->setData($response);

    }
    protected function getSuccessMessage($email)
    {
        return __(
            'If there is an account associated with %1 you will receive an email with a link to reset your password.',
            $this->escaper->escapeHtml($email)
        );
    }
}