<?php
/**
* Copyright © 2019 V2Agency . All rights reserved.
*
*/
namespace V2Agency\Sociallogin\Controller\Twitter;
class Connect extends \Magento\Framework\App\Action\Action
{
    protected $referer = null;
	protected $_scopeConfig;
    protected $_resultPageFactory;
    protected $_helper;
    protected $_helperTwitter;
    protected $_facebookHelper;
    protected $_json;
    protected $_coreRegistry;
    protected $_storeManager;
	protected $_customerSession;
    protected $_clientModel;
    protected $_resultRawFactory;
	public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Controller\Result\RawFactory $rawResultFactory,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
		\V2Agency\Sociallogin\Helper\Data $helper,
		\V2Agency\Sociallogin\Helper\Twitter $helperTwitter,
		\Magento\Framework\Controller\Result\JsonFactory $json,
		\Magento\Framework\Registry $coreRegistry,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Magento\Customer\Model\Session $customerSession,
		\V2Agency\Sociallogin\Model\Twitter\Client $clientModel
    )
    {
		$this->_scopeConfig 		 	= $scopeConfig;
        $this->_resultPageFactory 	 	= $resultPageFactory;
        $this->_resultRawFactory        = $rawResultFactory;
		$this->_helper 				 	= $helper;
		$this->_helperTwitter 			= $helperTwitter;
        $this->_json 	 			  	= $json;
		$this->_coreRegistry 			= $coreRegistry;
		$this->_storeManager			= $storeManager;
		$this->_customerSession			= $customerSession;
		$this->_clientModel				= $clientModel;
        parent::__construct($context);
	}

	public function execute()
	{
		$resultRaw = $this->_resultRawFactory->create();
        $customer = $this->_customerSession->getCustomer();
        try {
            $this->_connectCallback();
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }

        if(!empty($this->referer)) {
             $output = '<script type="text/javascript">newwindow=null;window.opener.location.href = \''.$this->referer.'\' ;window.close();</script>';
             return $resultRaw->setContents($output);
        } else {
             $output = '<script type="text/javascript">newwindow=null;window.opener.location.reload();window.close();</script>';
             return $resultRaw->setContents($output);

        }
    }

    protected function _connectCallback() {
        if ( !($params = $this->getRequest()->getParams()) || !($requestToken = unserialize($this->_customerSession->getTwitterRequestToken()))) {
            // Direct route access - deny
            return;
        }

        $this->referer = $this->_helper->getRedirectPageAfterAuth();

        if(isset($params['denied'])) {
            $this->messageManager->addNotice(__('Twitter Connect process aborted.'));
            return;
        }
        $token = $this->_clientModel->getAccessToken();
        $userInfo = (object) array_merge(
                (array) ($userInfo = $this->_clientModel->api('/account/verify_credentials.json', 'GET', array('skip_status' => true))),
                array('email' => sprintf('%s@twitter-user.com', strtolower($userInfo->screen_name)))
        );
        $customersByTwitterId = $this->_helperTwitter->getCustomersByTwitterId($userInfo->id);
        if($this->_customerSession->isLoggedIn()) {
            // Logged in user
            if($customersByTwitterId->count()) {
                // Twitter account already connected to other account - deny
                $this->messageManager->addNotice(__('Your Twitter account is already connected to one of our store accounts.'));
                return;
            }
            // Connect from account dashboard - attach
            $customer = $this->_customerSession->getCustomer();
            $this->_helperTwitter->connectByTwitterId(
                $customer,
                $userInfo->id
            );
            $this->messageManager->addSuccess(__('Your Twitter account is now connected to your store accout. You can now login using our Twitter SocialLogin button or using store account credentials you will receive to your email address.'));
            return;
        }
        if($customersByTwitterId->count()) {
            // Existing connected user - login
            $customer = $customersByTwitterId->getFirstItem();
            $this->_helperTwitter->loginByCustomer($customer);
            $this->messageManager->addSuccess(__('You have successfully logged in using your Twitter account.'));
            return;
        }

        $customersByEmail = $this->_helperTwitter->getCustomersByEmail($userInfo->email);
        if($customersByEmail->count()) {
            // Email account already exists
            $this->messageManager->addNotice(
				__('We find email already have an account at our store. Please try other email !')
			);
			return;
        }
        // New connection - create, attach, login
        if(empty($userInfo->name)) {
            throw new Exception(__('Sorry, could not retrieve your Twitter last name. Please try again.'));
        }
        $this->_helperTwitter->connectByCreatingAccount(
            $userInfo->email,
            $userInfo->name,
            $userInfo->id
        );
        $customersByTwitterId = $this->_helperTwitter->getCustomersByTwitterId($userInfo->id);
        if($customersByTwitterId->count()) {
            // Existing connected user - login
            $customer = $customersByTwitterId->getFirstItem();
            $this->_helperTwitter->loginByCustomer($customer);
            $this->messageManager->addSuccess(__('You have successfully logged in using your Twitter account.'));
            return;
        }
        $this->messageManager->addSuccess(__('Your Twitter account is now connected to your new user account at our store. You can login next time by the Twitter SocialLogin button.'));
        $this->messageManager->addNotice(__('Since Twitter doesn\'t support third-party access to your email address, we were unable to send you your store accout credentials. To be able to login using store account credentials you will need to update your email address and password using our <a href="%1">Edit Account Information</a>.', $this->_helper->getUrlBilder('customer/account/edit')));
    }

}
