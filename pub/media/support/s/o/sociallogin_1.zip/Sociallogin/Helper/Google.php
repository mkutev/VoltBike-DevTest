<?php
/**
* Copyright © 2019 V2Agency . All rights reserved.
*
*/
namespace V2Agency\Sociallogin\Helper;

class Google extends \Magento\Framework\App\Helper\AbstractHelper
{
    protected $_session;
    protected $_customerModel;
    protected $_clientModel;
    protected $_helper;
    protected $_messageManager;
    protected $_storeManager;

    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Customer\Model\Session $session,
        \Magento\Customer\Model\Customer $customerModel,
        \V2Agency\Sociallogin\Model\Google\Client $clientModel,
        \V2Agency\Sociallogin\Helper\Data $helper,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    ) {
        $this->_session             = $session;
        $this->_customerModel       = $customerModel;
        $this->_clientModel         = $clientModel;
        $this->_helper              = $helper;
        $this->_messageManager      = $messageManager;
        $this->_storeManager        = $storeManager;
        parent::__construct($context);
    }

    public function disconnect(\Magento\Customer\Model\Customer $customer) {
        try {
            //$client->setAccessToken($customer->getV2AgencySocialloginGtoken());
            $this->_clientModel->revokeToken();
        } catch (Exception $e) { }

        $pictureFilename = $this->_helper->getMediaBaseUrl($customer->getId());
        if(file_exists($pictureFilename)) {
            @unlink($pictureFilename);
        }
        $customer->setGgid(null)->save();
    }

    public function connectByGoogleId(
            \Magento\Customer\Model\Customer $customer,
            $ggId
    ){
        $customer->setGgid($ggId)->save();
        $this->_session->setCustomerAsLoggedIn($customer);
    }

    public function connectByCreatingAccount(
            $email,
            $firstName,
            $lastName,
            $ggId
    ){
        try{
            $password = substr(md5(rand()), 0, 8);
            $this->_customerModel->setStore($this->_storeManager->getStore())
                    ->setEmail($email)
                    ->setFirstname($firstName)
                    ->setLastname($lastName)
                    ->setGgid($ggId)
                    ->setPassword($password);
            $this->_customerModel->save();

            $data = array();
            $data['email']      = $email;
            $data['name']       = $firstName . ' ' . $lastName;
            $data['password']   = $this->_clientModel->_getShowPassword() ?  $password : __('Password auto generate');
            $senderInfo         = $this->_helper->getConfigValue('sociallogin_settings/sociallogin/email_from');
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $objectManager->get('V2Agency\Sociallogin\Helper\Email')->sendMail('sociallogin_settings_sociallogin_new_account',$data,$senderInfo,$email);

            $this->_session->setCustomerAsLoggedIn($this->_customerModel);
        }catch(\Exception $e){
            print_r($e->getMessage());
        }
    }

    public function loginByCustomer(\Magento\Customer\Model\Customer $customer)
    {
        if($customer->getConfirmation()) {
            $customer->setConfirmation(null);
            $customer->save();
        }
        $this->_session->setCustomerAsLoggedIn($customer);
    }

    public function getCustomersByGoogleId($ggId)
    {
        $collection = $this->_customerModel->getCollection()->addFieldToSelect('*')->addAttributeToFilter('ggid', $ggId);

        if($this->_customerModel->getSharingConfig()->isWebsiteScope()) {
            $collection->addAttributeToFilter(
                'website_id',
                $this->_storeManager->getStore()->getWebsiteId()
            );
        }

        if($this->_session->isLoggedIn()) {
            $collection->addFieldToFilter(
                'entity_id',
                array('neq' => $this->_session->getCustomerId())
            );
        }
        return $collection;
    }

    public function getCustomersByEmail($email)
    {
        $collection = $this->_customerModel->getCollection()->addFieldToSelect('*')->addFieldToFilter('email', $email);

        if($this->_customerModel->getSharingConfig()->isWebsiteScope()) {
            $collection->addAttributeToFilter(
                'website_id',
                $this->_storeManager->getStore()->getWebsiteId()
            );
        }

        if($this->_session->isLoggedIn()) {
            $collection->addFieldToFilter(
                'entity_id',
                array('neq' => $this->_session->getCustomerId())
            );
        }
        return $collection;
    }

    public function getProperDimensionsPictureUrl($customerId, $pictureUrl)
    {
        $url = $this->_helper->getMediaBaseUrl($customerId);
        $filename = $this->_helper->getMediaBaseUrl($customerId);

        $directory = dirname($filename);

        if (!file_exists($directory) || !is_dir($directory)) {
            if (!@mkdir($directory, 0777, true))
                return null;
        }

        if(!file_exists($filename) ||
                (file_exists($filename) && (time() - filemtime($filename) >= 3600))){
            $client = new \Zend_Http_Client($pictureUrl);
            $client->setStream();
            $response = $client->request('GET');
            stream_copy_to_stream($response->getStream(), fopen($filename, 'w'));

            $imageObj = new Varien_Image($filename);
            $imageObj->constrainOnly(true);
            $imageObj->keepAspectRatio(true);
            $imageObj->keepFrame(false);
            $imageObj->resize(150, 150);
            $imageObj->save($filename);
        }
        return $url;
    }

}
