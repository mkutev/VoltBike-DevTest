<?php
namespace V2Agency\Sociallogin\Helper;

use Magento\Framework\App\Helper\Context;
use Magento\Framework\Filesystem;
use Magento\Framework\App\Filesystem\DirectoryList;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{

	protected $_objectManager;
	protected $_timezoneInterface;
	protected $_registry;
	protected $_resultPageFactory;
	protected $_request;
	protected $_transportBuilder;
	protected $_fileSystem;
	protected $_session;
	protected $_storeManager;
	protected $_urlRewriteFactory;

    /**
     * Block constructor.
     *
     * @param \Magento\Framework\App\Helper\Context $context
     */
    public function __construct(Context $context,
		\Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Framework\Registry $registry,
		\Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezoneInterface,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory,
		\Magento\Framework\App\Request\Http $request,
		\Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
		Filesystem $fileSystem,
		\Magento\Customer\Model\Session $session,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Magento\UrlRewrite\Model\UrlRewrite $urlRewriteFactory
    ) {
		$this->_objectManager 		= $objectManager;
        $this->_registry 			= $registry;
		$this->_timezoneInterface 	= $timezoneInterface;
		$this->_resultPageFactory 	= $resultPageFactory;
		$this->_request 			= $request;
		$this->_transportBuilder 	= $transportBuilder;
		$this->_fileSystem 			= $fileSystem;
		$this->_session 			= $session;
		$this->_storeManager 		= $storeManager;
		$this->_urlRewriteFactory 	= $urlRewriteFactory;
        parent::__construct($context);
    }

	public function getUrlBilder($path = ''){
		 return $this->_urlBuilder->getUrl($path);
	}

	public function getModuleEnable()
    {
		return $this->getConfigValue('sociallogin_settings/sociallogin/enable');
    }

	public function getRedirectPage()
    {
		return $this->getConfigValue('sociallogin_settings/sociallogin/redirect_page');
    }

	public function getGroupButtonText()
    {
		return $this->getConfigValue('sociallogin_settings/sociallogin/group_button_text');
    }

	public function getFacebookState()
    {
		return $this->getConfigValue('sociallogin_settings/facebook/enable');
    }

	public function getFacebookAppId()
    {
		return $this->getConfigValue('sociallogin_settings/facebook/app_id');
    }

	public function getFacebookAppSecret()
    {
		return $this->getConfigValue('sociallogin_settings/facebook/app_secret');
    }

	public function getFacebookAppSendPassword()
    {
		return $this->getConfigValue('sociallogin_settings/facebook/send_password');
    }

	public function getFacebookOrder()
    {
		return $this->getConfigValue('sociallogin_settings/facebook/order');
    }

	public function getTwitterState()
    {
		return $this->getConfigValue('sociallogin_settings/twitter/enable');
    }

	public function getTwitterApiKey()
    {
		return $this->getConfigValue('sociallogin_settings/twitter/api_key');
    }

	public function getTwitterApiSecret()
    {
		return $this->getConfigValue('sociallogin_settings/twitter/api_secret');
    }

	public function getTwitterCallbackUrl()
    {
		return $this->getConfigValue('sociallogin_settings/twitter/callback_url');
    }

	public function getTwitterSendPassword()
    {
		return $this->getConfigValue('sociallogin_settings/twitter/send_password');
    }

	public function getTwitterOrder()
    {
		return $this->getConfigValue('sociallogin_settings/twitter/order');
    }

	public function getInstagramState()
    {
		return $this->getConfigValue('sociallogin_settings/instagram/enable');
    }

	public function getInstagramClientId()
    {
		return $this->getConfigValue('sociallogin_settings/instagram/client_id');
    }

	public function getInstagramClientSecret()
    {
		return $this->getConfigValue('sociallogin_settings/instagram/client_secret');
    }

	public function getInstagramCallbackUrl()
    {
		return $this->getConfigValue('sociallogin_settings/instagram/callback_url');
    }

	public function getInstagramSendPassword()
    {
		return $this->getConfigValue('sociallogin_settings/instagram/send_password');
    }

	public function getInstagramOrder()
    {
		return $this->getConfigValue('sociallogin_settings/instagram/order');
    }

	public function getGoogleState()
    {
		return $this->getConfigValue('sociallogin_settings/google/enable');
    }

	public function getGoogleClientId()
    {
		return $this->getConfigValue('sociallogin_settings/google/client_id');
    }

	public function getGoogleClientSecret()
    {
		return $this->getConfigValue('sociallogin_settings/google/client_secret');
    }

	public function getGoogleCallbackUrl()
    {
		return $this->getConfigValue('sociallogin_settings/google/callback_url');
    }

	public function getGoogleSendPassword()
    {
		return $this->getConfigValue('sociallogin_settings/google/send_password');
    }

	public function getGoogleOrder()
    {
		return $this->getConfigValue('sociallogin_settings/google/order');
    }

	public function getLinkedinState()
    {
		return $this->getConfigValue('sociallogin_settings/linkedin/enable');
    }

	public function getLinkedinClientId()
    {
		return $this->getConfigValue('sociallogin_settings/linkedin/client_id');
    }

	public function getLinkedinClientSecret()
    {
		return $this->getConfigValue('sociallogin_settings/linkedin/client_secret');
    }

	public function getLinkedinSendPassword()
    {
		return $this->getConfigValue('sociallogin_settings/linkedin/send_password');
    }

	public function getLinkedinOrder()
    {
		return $this->getConfigValue('sociallogin_settings/linkedin/order');
    }

	public function getYoutubeState()
    {
		return $this->getConfigValue('sociallogin_settings/youtube/enable');
    }

	public function getYoutubeClientId()
    {
		return $this->getConfigValue('sociallogin_settings/youtube/client_id');
    }

	public function getYoutubeClientSecret()
    {
		return $this->getConfigValue('sociallogin_settings/youtube/client_secret');
    }

	public function getYoutubeCallbackUrl()
    {
		return $this->getConfigValue('sociallogin_settings/youtube/callback_url');
    }

	public function getYoutubeSendPassword()
    {
		return $this->getConfigValue('sociallogin_settings/youtube/send_password');
    }

	public function getYoutubeOrder()
    {
		return $this->getConfigValue('sociallogin_settings/youtube/order');
    }

	public function getAmazonState()
    {
		return $this->getConfigValue('sociallogin_settings/amazon/enable');
    }

	public function getAmazonClientId()
    {
		return $this->getConfigValue('sociallogin_settings/amazon/client_id');
    }

	public function getAmazonClientSecret()
    {
		return $this->getConfigValue('sociallogin_settings/amazon/client_secret');
    }

	public function getAmazonSendPassword()
    {
		return $this->getConfigValue('sociallogin_settings/amazon/send_password');
    }

	public function getAmazonOrder()
    {
		return $this->getConfigValue('sociallogin_settings/amazon/order');
    }

	public function getConfigValue($path)
    {
        return $this->scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
    public function getPositionView(){
    	return $this->getConfigValue('sociallogin_settings/sociallogin/position');
    }

	public function isModuleEnabled($moduleName)
    {
        return $this->_moduleManager->isEnabled($moduleName);
    }

	public function getCustomerId()
    {
		$customerId = $this->_session->getCustomer()->getId() ? $this->_session->getCustomer()->getId() : 0;
        return $customerId;
    }

	public function getStore(){
		return $this->_storeManager->getStore();
	}

	public function getSubDir(){
		return 'v2agency_sociallogin/icon';
	}

	public function getMediaBaseUrl() {
		return $this->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA) . $this->getSubDir();
	}

	public function getBaseUrl($path = '') {
		return $this->getStore()->getBaseUrl() . $path;
	}

	public function getRedirectPageAfterAuth(){
		// Set Redirect page after authentication
		if($this->getRedirectPage() == 'account'){
			$redirect = $this->getUrlBilder('customer/account');
		}else if($this->getRedirectPage() == 'home'){
			$redirect = $this->getUrlBilder('');
		}else{
			$redirect = $this->getStore()->getCurrentUrl();
		}
		return $redirect;
	}
}
