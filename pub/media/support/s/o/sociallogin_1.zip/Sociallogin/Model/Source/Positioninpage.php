<?php
/**
* Copyright © 2019 V2Agency . All rights reserved.
*
*/
namespace V2Agency\Sociallogin\Model\Source;

class Positioninpage implements \Magento\Framework\Option\ArrayInterface
{
	public function toOptionArray()
    {
        return array(
            array(
                'value' => '',
                'label' => __('Select Display Position')
            ),
            array(
                'value' => 'fixedleft',
                'label' => __('Display fixed in left')
            ),
            array(
                'value' => 'fixedright',
                'label' => __('Display fixed in right')
            )

        );
    }
}
