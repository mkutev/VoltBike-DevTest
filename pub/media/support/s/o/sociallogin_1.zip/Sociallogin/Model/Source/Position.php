<?php
/**
* Copyright © 2019 V2Agency . All rights reserved.
*
*/
namespace V2Agency\Sociallogin\Model\Source;

class Position implements \Magento\Framework\Option\ArrayInterface
{
	public function toOptionArray()
    {
        return array(
            array(
                'value' => '',
                'label' => __('Select Page')
            ),
            array(
                'value' => 'account',
                'label' => __('Account Page')
            ),
            array(
                'value' => 'home',
                'label' => __('Home Page')
            ),
            array(
                'value' => 'current',
                'label' => __('Current Page')
            )
        );
    }
}
