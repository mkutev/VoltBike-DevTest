<?php
/**
* Copyright © 2019 V2Agency . All rights reserved.
*
*/
namespace V2Agency\Sociallogin\Model\Facebook;
class Client extends \Magento\Framework\Model\AbstractModel
{

    const REDIRECT_URI_ROUTE = 'v2agencysociallogin/facebook/connect';

    const XML_PATH_ENABLED = 'sociallogin_settings/facebook/enable';
    const XML_PATH_CLIENT_ID = 'sociallogin_settings/facebook/app_id';
    const XML_PATH_CLIENT_SECRET = 'sociallogin_settings/facebook/app_secret';
	const XML_PATH_SHOW_PASSWORD = 'sociallogin_settings/facebook/send_password';

    const OAUTH2_SERVICE_URI = 'https://graph.facebook.com';
    const OAUTH2_AUTH_URI = '/oauth/authorize';
    const OAUTH2_TOKEN_URI = '/oauth/access_token';

    protected $clientId = null;
    protected $clientSecret = null;
    protected $redirectUri = null;
    protected $state = '';
    protected $scope = array('email', 'user_birthday');

    protected $token = null;
    protected $_registry;
	protected $_urlBuilder;
	protected $_storeManager;
	protected $_scopeConfig;

    public function __construct(
		\Magento\Framework\Model\Context $context,
		\Magento\Framework\Registry $registry,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Magento\Framework\UrlInterface $urlBuilder,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
	){
		parent::__construct(
            $context,
            $registry
        );
		$this->_registry 		= $registry;
		$this->_storeManager 	= $storeManager;
		$this->_urlBuilder 		= $urlBuilder;
		$this->_scopeConfig 	= $scopeConfig;

        if(($this->isEnabled = $this->_isEnabled())) {
            $this->clientId = $this->_getClientId();
            $this->clientSecret = $this->_getClientSecret();
            $this->redirectUri  = $this->_urlBuilder->sessionUrlVar(
                $this->_urlBuilder->getUrl(self::REDIRECT_URI_ROUTE)
            );

            if(!empty($params['scope'])) {
                $this->scope = $params['scope'];
            }

            if(!empty($params['state'])) {
                $this->state = $params['state'];
            }
        }
    }

    public function isEnabled()
    {
        return (bool) $this->isEnabled;
    }

    public function getClientId()
    {
        return $this->clientId;
    }

    public function getClientSecret()
    {
        return $this->clientSecret;
    }

    public function getRedirectUri()
    {
        return $this->redirectUri;
    }

    public function getScope()
    {
        return $this->scope;
    }

    public function getState()
    {
        return $this->state;
    }

    public function setState($state)
    {
        $this->state = $state;
    }

    public function setAccessToken($token)
    {
        $this->token = $token;
    }

    public function getAccessToken()
    {
        if(empty($this->token)) {
            $this->fetchAccessToken();
        }
        return $this->token;
    }

    public function createAuthUrl()
    {
        $url =
        self::OAUTH2_SERVICE_URI . self::OAUTH2_AUTH_URI.'?'.
            http_build_query(
                array(
                    'client_id' => $this->clientId,
                    'redirect_uri' => $this->redirectUri,
                    'scope' => implode(',', $this->scope)
				)
            );
        return $url;
    }

    public function api($endpoint, $method = 'GET', $params = array())
    {
        if(empty($this->token)) {
            $this->fetchAccessToken();
        }
        $url = $endpoint;

        $method = strtoupper($method);
        //var_dump($this->token);die;
        if($this->token->access_token){
            $params = array_merge(array(
            'fields' => 'id,name,email,first_name,last_name',
            'access_token' => $this->token->access_token
             ), $params);
        }

        $response = $this->_httpRequest($url, $method, $params);
        return json_decode($response);
    }

    protected function fetchAccessToken()
    {
        if(empty($_REQUEST['code'])) {
            throw new Exception(__('Unable to retrieve access code.'));
        }

        $response = $this->_httpRequest(
            self::OAUTH2_TOKEN_URI,
            'POST',
            array(
                'code' => $_REQUEST['code'],
                'redirect_uri' => $this->redirectUri,
                'client_id' => $this->clientId,
                'client_secret' => $this->clientSecret,
                'grant_type' => 'authorization_code'
            )
        );
        //var_dump((object)$response);die;

		// parse_str($response, $output);

        $this->token = json_decode($response);
    }

	private function _httpRequest($path, $method = 'GET', $params = array()) {
		/** @var \Zend\Uri\Http $uri */
		$uri = new \Zend\Uri\Http(self::OAUTH2_SERVICE_URI);
		$uri->setPath($path);
		$uri->setQuery($params);
		/** http://stackoverflow.com/a/3367977 */
		/** @var \Zend\Http\Client\Adapter\Curl $adapter */
		$adapter = new \Zend\Http\Client\Adapter\Curl;
		$adapter->setCurlOption(CURLOPT_SSL_VERIFYPEER, false);
		/** @var \Zend\Http\Client $httpClient */
		$httpClient = new \Zend\Http\Client();
		$httpClient
			->setAdapter($adapter)
			->setHeaders([
				'Authorization' => 'Bearer',
				'Accept' => 'application/json',
				'Content-Type' => 'application/json'
			])
			->setUri($uri)
			->setOptions(['timeout' => 60])
		;
		if($method == 'GET'){$httpClient->setMethod(\Zend\Http\Request::METHOD_GET);}
		/** @var \Zend\Http\Response $response */
		$response = $httpClient->send();
        return $response->getBody();
	}

    protected function _isEnabled()
    {
        return $this->_getStoreConfig(self::XML_PATH_ENABLED);
    }

    protected function _getClientId()
    {
        return $this->_getStoreConfig(self::XML_PATH_CLIENT_ID);
    }

    protected function _getClientSecret()
    {
        return $this->_getStoreConfig(self::XML_PATH_CLIENT_SECRET);
    }

	protected function _getShowPassword()
    {
        return $this->_getStoreConfig(self::XML_PATH_SHOW_PASSWORD);
    }

    protected function _getStoreConfig($xmlPath)
    {
        return $this->_scopeConfig->getValue($xmlPath, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
}