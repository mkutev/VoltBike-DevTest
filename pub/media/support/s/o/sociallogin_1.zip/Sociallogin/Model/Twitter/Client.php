<?php
/**
* Copyright © 2019 V2Agency . All rights reserved.
*
*/
namespace V2Agency\Sociallogin\Model\Twitter;
class Client extends \Magento\Framework\Model\AbstractModel
{
    const REDIRECT_URI_ROUTE = 'v2agencysociallogin/twitter/connect';
    const REQUEST_TOKEN_URI_ROUTE = 'v2agencysociallogin/twitter/request';

    const OAUTH_URI = 'https://api.twitter.com/oauth';
    const OAUTH2_SERVICE_URI = 'https://api.twitter.com/1.1';

    const XML_PATH_ENABLED = 'sociallogin_settings/twitter/enable';
    const XML_PATH_CLIENT_ID = 'sociallogin_settings/twitter/api_key';
    const XML_PATH_CLIENT_SECRET = 'sociallogin_settings/twitter/api_secret';
	const XML_PATH_SHOW_PASSWORD = 'sociallogin_settings/twitter/send_password';

    protected $clientId = null;
    protected $clientSecret = null;
    protected $redirectUri = null;
    protected $client = null;
    protected $token = null;
	protected $_registry;
	protected $_urlBuilder;
	protected $_storeManager;
	protected $_session;
	protected $_request;
	protected $_scopeConfig;

    public function __construct(
		\Magento\Framework\Model\Context $context,
		\Magento\Framework\Registry $registry,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Magento\Framework\UrlInterface $urlBuilder,
		\Magento\Customer\Model\Session $session,
		\Magento\Framework\App\Request\Http $request,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
	){
		parent::__construct(
            $context,
            $registry
        );
		$this->_registry 		= $registry;
		$this->_storeManager 	= $storeManager;
		$this->_urlBuilder 		= $urlBuilder;
		$this->_session 		= $session;
		$this->_request 		= $request;
		$this->_scopeConfig 	= $scopeConfig;

		if(($this->isEnabled = $this->_isEnabled())) {
			$this->clientId = $this->_getClientId();
			$this->clientSecret = $this->_getClientSecret();
			$this->redirectUri = $this->_urlBuilder->sessionUrlVar(
				$this->_urlBuilder->getUrl(self::REDIRECT_URI_ROUTE)
            );

            $this->client = new \Zend_Oauth_Consumer(
                array(
                    'callbackUrl' => $this->redirectUri,
                    'siteUrl' => self::OAUTH_URI,
                    'authorizeUrl' => self::OAUTH_URI.'/authenticate',
                    'consumerKey' => $this->clientId,
                    'consumerSecret' => $this->clientSecret
                )
            );
         }
    }

    public function isEnabled()
    {
        return (bool) $this->isEnabled;
    }

    public function getClient()
    {
        return $this->client;
    }

    public function getClientId()
    {
        return $this->clientId;
    }

    public function getClientSecret()
    {
        return $this->clientSecret;
    }

    public function getRedirectUri()
    {
        return $this->redirectUri;
    }

    public function setAccessToken($token)
    {
        $this->token = unserialize($token);
    }

    public function getAccessToken()
    {
        if(empty($this->token)) {
            $this->fetchAccessToken();
        }

        return serialize($this->token);
    }

    public function createAuthUrl()
    {
        return $this->_urlBuilder->getUrl(self::REQUEST_TOKEN_URI_ROUTE);
    }

    public function fetchRequestToken()
    {
        if(!($requestToken = $this->client->getRequestToken())) {
            throw new Exeption(__('Unable to retrieve request token.'));
        }

        $this->_session->setTwitterRequestToken(serialize($requestToken));

        $this->client->redirect();
    }

    protected function fetchAccessToken()
    {
        if (!($params = $this->_request->getParams()) || !($requestToken = $this->_session->getTwitterRequestToken())) {
            throw new Exception(__('Unable to retrieve access code.'));
        }
        if(!($token = $this->client->getAccessToken( $params, unserialize($requestToken)))) {
            throw new Exeption(__('Unable to retrieve access token.'));
        }
        $this->_session->unsTwitterRequestToken();

        return $this->token = $token;
    }

    public function api($endpoint, $method = 'GET', $params = array())
    {
        if(empty($this->token)) {
            throw new Exception(__('Unable to proceed without an access token.'));
        }
        $url = self::OAUTH2_SERVICE_URI.$endpoint;

        $response = $this->_httpRequest($url, strtoupper($method), $params);
        return $response;
    }

    protected function _httpRequest($url, $method = 'GET', $params = array())
    {
        $client = $this->token->getHttpClient(
            array(
                'callbackUrl' => $this->redirectUri,
                'siteUrl' => self::OAUTH_URI,
                'consumerKey' => $this->clientId,
                'consumerSecret' => $this->clientSecret
            )
        );
        $client->setUri($url);
        switch ($method) {
            case 'GET':
                $client->setMethod(\Zend_Http_Client::GET);
                $client->setParameterGet($params);
                break;
            case 'POST':
                $client->setMethod(\Zend_Http_Client::POST);
                $client->setParameterPost($params);
                break;
            case 'DELETE':
                $client->setMethod(\Zend_Http_Client::DELETE);
                break;
            default:
                throw new Exception(__('Required HTTP method is not supported.'));
        }

        $response = $client->request();
        $decoded_response = json_decode($response->getBody());

        if($response->isError()) {
            $status = $response->getStatus();
            if(($status == 400 || $status == 401 || $status == 429)) {
                if(isset($decoded_response->error->message)) {
                    $message = $decoded_response->error->message;
                } else {
                    $message = __('Unspecified OAuth error occurred.');
                }
                throw new V2Agency_Sociallogin_TwitterOAuthException($message);
            } else {
                $message = __('HTTP error %1 occurred while issuing request.',$status);
                throw new Exception($message);
            }
        }
        return $decoded_response;
    }

    protected function _isEnabled()
    {
        return $this->_getStoreConfig(self::XML_PATH_ENABLED);
    }

    protected function _getClientId()
    {
        return $this->_getStoreConfig(self::XML_PATH_CLIENT_ID);
    }

    protected function _getClientSecret()
    {
        return $this->_getStoreConfig(self::XML_PATH_CLIENT_SECRET);
    }

    protected function _getShowPassword()
    {
        return $this->_getStoreConfig(self::XML_PATH_SHOW_PASSWORD);
    }

    protected function _getStoreConfig($xmlPath)
    {
        return $this->_scopeConfig->getValue($xmlPath, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

}

