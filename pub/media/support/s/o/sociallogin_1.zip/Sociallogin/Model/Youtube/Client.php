<?php
/**
* Copyright © 2019 V2Agency . All rights reserved.
*
*/
namespace V2Agency\Sociallogin\Model\Youtube;
class Client extends \Magento\Framework\Model\AbstractModel
{
    const REDIRECT_URI_ROUTE = 'v2agencysociallogin/youtube/connect';

    const XML_PATH_ENABLED = 'sociallogin_settings/youtube/enable';
    const XML_PATH_CLIENT_ID = 'sociallogin_settings/youtube/client_id';
    const XML_PATH_CLIENT_SECRET = 'sociallogin_settings/youtube/client_secret';
	const XML_PATH_SHOW_PASSWORD = 'sociallogin_settings/youtube/send_password';

    const OAUTH2_REVOKE_URI = 'https://accounts.google.com/o/oauth2/revoke';
    const OAUTH2_TOKEN_URI = 'https://accounts.google.com/o/oauth2/token';
	const OAUTH2_AUTH_URI = 'https://accounts.google.com/o/oauth2/auth';
    const OAUTH2_SERVICE_URI = 'https://www.googleapis.com/oauth2/v2';

    protected $isEnabled = null;
    protected $clientId = null;
    protected $clientSecret = null;
    protected $redirectUri = null;
    protected $state = '';
    protected $scope = array(
		'https://www.googleapis.com/auth/youtube',
		'https://www.googleapis.com/auth/yt-analytics.readonly',
		'https://gdata.youtube.com'
    );

    protected $access = 'offline';
    protected $prompt = 'auto';
    protected $token = null;

	protected $_registry;
	protected $_urlBuilder;
	protected $_storeManager;
	protected $_scopeConfig;


    public function __construct(
		\Magento\Framework\Model\Context $context,
		\Magento\Framework\Registry $registry,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Magento\Framework\UrlInterface $urlBuilder,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
	){
		parent::__construct(
            $context,
            $registry
        );
		$this->_registry 		= $registry;
		$this->_storeManager 	= $storeManager;
		$this->_urlBuilder 		= $urlBuilder;
		$this->_scopeConfig 	= $scopeConfig;

        if(($this->isEnabled = $this->_isEnabled())) {
            $this->clientId = $this->_getClientId();
            $this->clientSecret = $this->_getClientSecret();
            $this->redirectUri  = $this->_urlBuilder->sessionUrlVar(
                $this->_urlBuilder->getUrl(self::REDIRECT_URI_ROUTE)
            );

            if(!empty($params['scope'])) {
                $this->scope = $params['scope'];
            }

            if(!empty($params['state'])) {
                $this->state = $params['state'];
            }

            if(!empty($params['access'])) {
                $this->access = $params['access'];
            }

            if(!empty($params['prompt'])) {
                $this->prompt = $params['prompt'];
            }
        }
    }

    public function isEnabled()
    {
        return (bool) $this->isEnabled;
    }

    public function getClientId()
    {
        return $this->clientId;
    }

    public function getClientSecret()
    {
        return $this->clientSecret;
    }

    public function getRedirectUri()
    {
        return $this->redirectUri;
    }

    public function getScope()
    {
        return $this->scope;
    }

    public function getState()
    {
        return $this->state;
    }

    public function setState($state)
    {
        $this->state = $state;
    }

    public function getAccess()
    {
        return $this->access;
    }

    public function setAccess($access)
    {
        $this->access = $access;
    }

    public function getPrompt()
    {
        return $this->prompt;
    }

    public function setPrompt($prompt)
    {
        $this->access = $prompt;
    }

    public function setAccessToken($token)
    {
        $this->token = $token;
    }

    public function getAccessToken()
    {
        if(empty($this->token)) {
            $this->fetchAccessToken();
        } else if($this->isAccessTokenExpired()) {
            $this->refreshAccessToken();
        }
        return $this->token;
    }

    public function createAuthUrl()
    {

        $url =
		self::OAUTH2_AUTH_URI.'?'.
            http_build_query(
                array(
                    'response_type' => 'code',
                    'redirect_uri' => $this->redirectUri,
                    'client_id' => $this->clientId,
                    'scope' => implode(' ', $this->scope),
                    'access_type' => $this->access,
                    'approval_prompt' => $this->prompt
				)
            );
        return $url;
    }

    public function api($endpoint, $method = 'GET', $params = array())
    {
        if(empty($this->token)) {
            $this->fetchAccessToken();
        } else if($this->isAccessTokenExpired()) {
            $this->refreshAccessToken();
        }
        $url = 'https://www.googleapis.com/youtube/v3/channels';
        $method = strtoupper($method);
        $params = array_merge(array(
            'access_token' => $this->token->access_token,
            'part' => 'id,brandingSettings',
            'mine' => 'true'
        ), $params);
        $response = $this->_httpRequest($url, $method, $params);
        return $response;
    }

    public function revokeToken()
    {
        if(empty($this->token)) {
            throw new Exception(__('No access token available.'));
        }
        if(empty($this->token->refresh_token)) {
            throw new Exception(__('No refresh token, nothing to revoke.'));
        }
        $this->_httpRequest(
            self::OAUTH2_REVOKE_URI,
            'POST',
			array(
               'token' => $this->token->refresh_token
			)
        );
    }

    protected function fetchAccessToken()
    {
        if(empty($_REQUEST['code'])) {
            throw new Exception(__('Unable to retrieve access code.'));
        }
        $response = $this->_httpRequest(
            self::OAUTH2_TOKEN_URI,
            'POST',
            array(
                'code' => $_REQUEST['code'],
                'redirect_uri' => $this->redirectUri,
                'client_id' => $this->clientId,
                'client_secret' => $this->clientSecret,
                'grant_type' => 'authorization_code'
            )
        );
		$response->created = time();
        $this->token = $response;
    }

    protected function refreshAccessToken()
    {
        if(empty($this->token->refresh_token)) {
            throw new Exception(__('No refresh token, unable to refresh access token.'));
        }
        $response = $this->_httpRequest(
            self::OAUTH2_TOKEN_URI,
            'POST',
            array(
                'client_id' => $this->clientId,
                'client_secret' => $this->clientSecret,
                'refresh_token' => $this->token->refresh_token,
                'grant_type' => 'refresh_token'
            )
        );
        $this->token->access_token = $response->access_token;
        $this->token->expires_in = $response->expires_in;
        $this->token->created = time();
    }

    protected function isAccessTokenExpired() {
        // If the token is set to expire in the next 30 seconds.
        $expired = ($this->token->created + ($this->token->expires_in - 30)) < time();
        return $expired;
    }

    protected function _httpRequest($url, $method = 'GET', $params = array())
    {

		$writer = new \Zend\Log\Writer\Stream(BP . '/var/log/request.log');
		$logger = new \Zend\Log\Logger();
		$logger->addWriter($writer);
        $client = new \Zend_Http_Client($url, array('timeout' => 60));

        switch ($method) {
            case 'GET':
                $client->setParameterGet($params);
                break;
            case 'POST':
                $client->setParameterPost($params);
                break;
            case 'DELETE':
                break;
            default:
                throw new Exception(__('Required HTTP method is not supported.'));
        }

        $response = $client->request($method);
        $decoded_response = json_decode($response->getBody());
        if($response->isError()) {
            $status = $response->getStatus();
            if(($status == 400 || $status == 401)) {
                if(isset($decoded_response->error->message)) {
                    $message = $decoded_response->error->message;
                } else {
                    $message = __('Unspecified OAuth error occurred.');
                }
                throw new V2Agency_Sociallogin_GoogleOAuthException($message);
            } else {
                $message = __('HTTP error %1 occurred while issuing request.',$status);
                throw new Exception($message);
            }
        }
        return $decoded_response;
    }

    protected function _isEnabled()
    {
        return $this->_getStoreConfig(self::XML_PATH_ENABLED);
    }

    protected function _getClientId()
    {
        return $this->_getStoreConfig(self::XML_PATH_CLIENT_ID);
    }

    protected function _getClientSecret()
    {
        return $this->_getStoreConfig(self::XML_PATH_CLIENT_SECRET);
    }

	protected function _getShowPassword()
    {
        return $this->_getStoreConfig(self::XML_PATH_SHOW_PASSWORD);
    }

    protected function _getStoreConfig($xmlPath)
    {
        return $this->_scopeConfig->getValue($xmlPath, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
}
